#include"lib.h"

char *meson_print(void)
{
  return "Hello, world!";
}
