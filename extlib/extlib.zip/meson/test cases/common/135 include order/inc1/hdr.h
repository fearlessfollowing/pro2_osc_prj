#define SOME_DEFINE 42
