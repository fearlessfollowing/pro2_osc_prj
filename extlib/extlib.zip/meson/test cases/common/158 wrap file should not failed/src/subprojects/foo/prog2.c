#include<stdio.h>

int main(int argc, char **argv) {
    printf("Do not have a file layout like this in your own projects.\n");
    printf("This is only to test that this works.\n");
    return 0;
}
