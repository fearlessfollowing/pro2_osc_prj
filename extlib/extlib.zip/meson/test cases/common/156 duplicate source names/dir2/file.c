int dir2 = 20;
