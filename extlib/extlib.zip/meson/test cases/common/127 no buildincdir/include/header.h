#pragma once

int foobar();
