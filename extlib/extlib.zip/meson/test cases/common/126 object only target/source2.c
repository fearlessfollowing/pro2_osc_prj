int func2_in_obj() {
    return 0;
}
