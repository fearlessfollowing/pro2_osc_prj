int func3_in_obj() {
    return 0;
}
