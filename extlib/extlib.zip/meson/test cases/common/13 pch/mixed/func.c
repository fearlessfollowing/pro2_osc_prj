void tmp_func() {
    fprintf(stdout, "This is a function that fails if stdio is not #included.\n");
}

int cfunc() {
    return 0;
}
