#if !defined(_MSC_VER)
#error "This file is only for use with MSVC."
#endif

#include "prog.hh"
