#include"gen_func.h"

int main(int argc, char **argv) {
    unsigned int i = (unsigned int) gen_func_in_lib();
    unsigned int j = (unsigned int) gen_func_in_obj();
    unsigned int k = (unsigned int) gen_func_in_src();
    return (int)(i + j + k);
}
