//
// Created by vans on 17-3-1.
//
#include "oled_light.h"
#include "ins_i2c.h"
#include "stlog/stlog.h"

using namespace std;
#define TAG "oled_light"

oled_light::oled_light()
{
    init();
}

oled_light::~oled_light()
{
    deinit();
}

void oled_light::init()
{
    mI2CLight = sp<ins_i2c>(new ins_i2c(1,0x77));
    mI2CLight->i2c_write_byte(0x06,0x00);
}
#if 0
void oled_light::light_off(u8 uIndex)
{
    u8 val =~(0 << uIndex);
    set_light_val(val);
}

void oled_light::light_off_all()
{
    set_light_val(LIGHT_OFF);
}

void oled_light::light_on(u8 uIndex)
{
    u8 val = (0 << uIndex);
    set_light_val(val);
}

void oled_light::light_on_all()
{
    set_light_val(LIGHT_ALL);
}
#endif

void oled_light::set_light_val(u8 val)
{
    //keep audio on
    if(mI2CLight->i2c_write_byte(0x02,val) != 0)
    {
        Log.e(TAG," oled write val 0x%x fail",val);
    }
}

void oled_light::deinit()
{

}



