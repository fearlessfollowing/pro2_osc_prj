
#include <fstream>
#include <sstream>
#include "include_common.h"
#include "wifi_state.h"
#include <string>

#define TAG "InstaWifi"

//using namespace std;

static int SystemCall(const char *cmd) {
    int status = system(cmd);
    if (status == -1) {
        return status;
    }

    if (WIFEXITED(status)) {
        return WEXITSTATUS(status);
    } else {
        return -1;
    }
}

static string parseFileParam(string path, string key) {
    ifstream fin(path);
    if (!fin) {
        return string("");
    }

    string s;
    do {
        fin >> s;
    } while (!fin.eof() && s.find(key)==string::npos);

    fin.close();
    if (s.find(key) != string::npos) {
        size_t pos = s.find('=');
        return s.substr(pos+1);
    } else {
        return string("");
    }
}

static int setFileParam(string path, string key, string value) {
    string cmd;
    cmd += "sed";
    cmd += " -i \'s/^[\t\n\x0B\f\r]*" + key + "=.*$/" + key + "=" + value + "/g\'";
    cmd += " " + path;
    return parseFileParam(path, key) == "" ?
            -1 : SystemCall(cmd.c_str());
}

static string parseCommand(string cmd, string key) {
    string cmd_ = cmd + " > /data/.tmp_wifi";
    system(cmd_.c_str());

    FILE *fp = fopen("/data/.tmp_wifi", "r");
    if(NULL == fp) {
        Log.w(TAG,"cannot open pipe: %s", cmd.c_str());
        return string("");
    }

    char *find = 0;
    char line[1024];
    while(!feof(fp) && fgets(line,sizeof(line),fp) != NULL) {
        find = strstr(line, key.c_str());
        if(find) {
			fclose(fp);
            return strlen(find) > key.length() + 1 ? 
                    string(find + key.length() + 1):
                    string("\\true");
        }
    }

    // Log.d(TAG,"cannot find %s in command %s", key.c_str(), cmd.c_str());
    fclose(fp);
    system("rm /data/.tmp_wifi");
    return string("\\false");
}

static char *getCommand(string cmd) {
    static char buf[1024];
    string cmd_ = cmd + " > /data/.tmp_wifi";
    system(cmd_.c_str());

    memset(buf, 0, 1024);

    FILE *fp = fopen("/data/.tmp_wifi", "r");
    if(NULL == fp) {
        Log.w(TAG,"cannot open pipe: %s", cmd.c_str());
        return buf;
    }

    fseek(fp, 0, SEEK_END);
    size_t size = ftell(fp);
    fseek(fp, 0, SEEK_SET);

    if (size > 1024) 
        return buf;

    fread(buf, 1, size, fp);

    fclose(fp);
    system("rm /data/.tmp_wifi");
    return (char *)buf;
}

const char *cliHead = "ifname = wlan0\n";
static string cliGetNetwork(int idx, string param) {
    string cmd;
    char idx_str[256] = {0};

    string sidx(idx_str);	
    sprintf(idx_str, "%d", idx);

    cmd += "wpa_cli";
    cmd += " -p /data/misc/wifi/sockets/";
    cmd += " -iwlan0 ";
    cmd += "get_network " + sidx + " " + param;
    //cmd += "get_network " + std::to_string(idx) + " " + param;

    string s(getCommand(cmd));
    if (s == "FAIL\n") 
        return s;

    if (s.find(cliHead) != string::npos) {
        s = s.substr(strlen(cliHead));
    }
    
    // get inside content
    size_t start, end;
    start = s.find("\"");
    end = s.rfind("\"");

    if (start != string::npos)
        s = s.substr(start + 1, end - start - 1);

    return s;
}


WifiState::WifiState() {}
WifiState::~WifiState() {}

int WifiSta::cliCommand(string subcmd) {
    if (!isRunning())
        enable();

    string cmd;
    cmd += "wpa_cli";
    cmd += " -p /data/misc/wifi/sockets/";
    cmd += " -iwlan0 ";
    return parseCommand(cmd + subcmd, "OK") != "\\true";
}

WifiSta::WifiSta(WifiContext &context) 
: context_(context) {
    enable();

    ssid_ = cliGetNetwork(0, "ssid");
    if (ssid_ == "FAIL\n") {
        Log.i(TAG,"resetting network");
        reset();
    }
    else 
        Log.i(TAG,"sta running at: ssid=%s", ssid_.c_str());
} 

int WifiSta::setSSID(const char *str) {
    ssid_ = str;
    Log.i(TAG,"sta setting SSID to %s", str);
    reset(); 
    
    if (cliCommand("set_network 0 ssid \\\"" + ssid_ + "\\\"")) {
         Log.e(TAG,"error setting sta ssid to %s", ssid_.c_str());
        ssid_ = "";
        return -1;
    }
    cliCommand("save_config");
    return 0;
}

int WifiSta::setPassword(const char *str) {
    if (strlen(str) < 8) {
        if (!strcmp(str, "")) {
            password_ = "";
            return setEncryptMode("NONE");
        } else {
            Log.e(TAG,"password too short");
            return -1;
        }
    } else {
        password_ = str;
        Log.i(TAG,"sta setting password to %s", str);

        if (cliCommand("set_network 0 psk \\\"" + password_ + "\\\"")) {
            Log.e(TAG,"error setting sta password to %s", password_.c_str());
            password_ = "";
            return -1;
        }

        setEncryptMode("WPA-PSK WPA-EAP");
        cliCommand("save_config");
        return 0;
    }
}

int WifiSta::setEncryptMode(const char *str) {
    Log.i(TAG,"sta setting encrypt mode to %s", str);

    if (cliCommand("set_network 0 key_mgmt " + string(str))) {
        Log.e(TAG,"error setting sta mode to %s", mode_.c_str());
        return -1;
    }
    cliCommand("save_config");

    mode_ = str;
    return 0;
}

static string ipQuery(string node_path, string iface) {
    string cmd;
    cmd += "wpa_cli";
    cmd += " -p" + node_path;
    cmd += " -i" + iface;
    cmd += " status";
    string ip = parseCommand(cmd, "ip_address");
    return ip == "\\false" ? "" : ip;
}

string WifiSta::ip() {
    return ipQuery(node_path_, "wlan0");
}

int WifiSta::start() {
    enable();
    if (connect()) {
        disable();
        return -1;
    }
    return 0;
}

int WifiSta::stop() {
    return isRunning() ? disable() : 0;
}

int WifiSta::enable() {
    if (isRunning()) {
        return 0;
    }

    if (SystemCall("svc wifi enable")) {
        Log.e(TAG,"cannot init wpa_supplicant");
        return -1;
    }

    usleep(1000*1000);
    return 0;
}

int WifiSta::disable() {
    Log.i(TAG,"stopping sta");
    quit_ = true;
    disconnect();
    SystemCall("svc wifi disable");
    SystemCall("ifconfig wlan0 down");
    return 0;
}

int WifiSta::do_connect() {
    if (!isRunning()) {
        Log.d(TAG,"sta daemon is not running");
        return -1;
    }

    if ((ssid_ == "") ||
            (mode_ != "NONE" && password_.length() < 8))
    {
        Log.w(TAG,"sta started with invalid ssid/password, aborting..");
        return -1;
    }
    
    Log.i(TAG,"sta connecting ssid=%s, password=%s", ssid_.c_str(), password_.c_str());
    if (cliCommand("enable_network 0")) {
        Log.e(TAG,"connection failed");
        return -1;
    }
    return 0;
}

int WifiSta::do_disconnect() {
    return cliCommand("disable_network 0");
}

int WifiSta::reconnect() {
    static bool flip = true;

    if (flip) {
        Log.i(TAG,"sta reconnecting to %s", ssid_.c_str());
        cliCommand("reconnect");
        usleep(1000*1000*10);
    } else {
        Log.i(TAG,"sta scanning for %s", ssid_.c_str());
        cliCommand("scan");
        usleep(1000*1000*10);
    }
    flip = !flip;
    return 0;
}

static void ipQueryThread(WifiSta *sta) {
    string ip;
    bool now = false, last = false;
    bool need_reconn = false;
    
    while(!sta->quit_) 
    {
        ip = ipQuery(sta->node_path_, "wlan0");
        if (ip == "") {
            now = false;
            if (now != last) {
                need_reconn = true;
                Log.i(TAG,"sta disconnected from %s", sta->getSSID().c_str());
            }
            if (need_reconn)
                sta->reconnect();
        } else {
            now = true;
            need_reconn = false;
            if (now != last)
                Log.i(TAG,"sta connected with IP: %s", ip.c_str());
        }
        last = now;
        usleep(1000*1000);
    } 
    
    sta->quit_ = false;
}

int WifiSta::connect() {
    if (isConnected())
        return 0;

    if (do_connect())
        return -1;

    quit_ = false;
    ip_thread_ = thread(ipQueryThread, this);
    ip_thread_.detach();
    return 0;
}

int WifiSta::disconnect() {
    return do_disconnect();
}

bool WifiSta::isConnected() {
    if (!isRunning()) 
        return false;

    string cmd;
    cmd = "wpa_cli";
    cmd += " -p" + node_path_;
    cmd += " -iwlan0";
    cmd += " status";
    return parseCommand(cmd, "COMPLETED") == "\\true";
}

int WifiSta::reset() {    
    enable();

    Log.i(TAG,"sta resetting network config");
    cliCommand("remove_network 0");
    cliCommand("remove_network 1");
    cliCommand("save_config");
    disable();
    enable();
    cliCommand("add_network");
    cliCommand("save_config");
    return 0;
}

bool WifiSta::isRunning() {
    return parseCommand("ps", "wpa_supplicant") == "\\true";
}



WifiAp::WifiAp(WifiContext &context)
: context_(context) {
    string c = parseFileParam(conf_path_, "channel");
    string f = parseFileParam(conf_path_, "hw_mode");

    ssid_ = parseFileParam(conf_path_, "ssid");
    password_ = parseFileParam(conf_path_, "wpa_passphrase");
    channel_ = atoi(c.c_str());
    freq_ = f == string("g") ? AP_FREQ_2G : AP_FREQ_5G;

    if (ssid_ == "" || password_ == "") {
        Log.d(TAG,"ap running with invalid config file, resetting");
        reset();
    } else {
        Log.d(TAG,"softap running at:");
        Log.d(TAG,"\tssid=%s", ssid_.c_str());
        Log.d(TAG,"\tpassword=%s", password_.c_str());
        Log.d(TAG,"\tchannel=%d", channel_);
        Log.d(TAG,"\tfrequency=%s", freq_ == AP_FREQ_2G ? "2.4G" : "5G");
    }
}

int WifiAp::setSSID(const char *str) {
    Log.d(TAG,"ap setting SSID to %s", str);
    return setFileParam(conf_path_, "ssid", string(str));
}

int WifiAp::setPassword(const char *str) {
    if (strlen(str) < 8) {
        Log.d(TAG,"password too short");
        return -1;
    }
    Log.d(TAG,"ap setting password to %s", str);
    return setFileParam(conf_path_, "wpa_passphrase", string(str));
}

int WifiAp::setChannel(int c) {
    std::stringstream ss;
    string s;
    ss << c;
    ss >> s;
    Log.d(TAG,"ap setting channel to %d", c);
    return setFileParam(conf_path_, "channel", s);
}

int WifiAp::setFreq(ApFreq f) {
    Log.d(TAG,"ap setting frequency to %s", f==AP_FREQ_2G ? "2.4G" : "5G");
    return setFileParam(conf_path_, "hw_mode", f==AP_FREQ_2G ? "g" : "a");
}

int WifiAp::start() {
    return enable();
}

int WifiAp::stop() {
    return isRunning() ? disable() : 0;
}

int WifiAp::enable() {
    if (isRunning()) {
        Log.i(TAG,"daemon already running");
        return 0;
    }

    Log.d(TAG,"starting ap with");
    Log.d(TAG,"\tssid=%s", ssid_.c_str());
    Log.d(TAG,"\tpassword=%s", password_.c_str());
    Log.d(TAG,"\tchannel=%d", channel_);
    Log.d(TAG,"\tfrequency=%s", freq_ == AP_FREQ_2G ? "2.4G" : "5G");

    string cmd;
    cmd = "echo 2 > ";
    cmd += op_mode_path_;
    SystemCall(cmd.c_str());

    SystemCall("ndc softap startap");
    
    cmd = "ifconfig wlan0 " + ip_ + " netmask 255.255.255.0";
    SystemCall(cmd.c_str());
    
    cmd = "dnsmasq --no-daemon --no-resolv --no-poll";
    cmd += " --dhcp-range=" + ip_range_ + ",10h&";
    SystemCall(cmd.c_str());
    return 0;
}

int WifiAp::disable() {
    Log.i(TAG,"ap stopping");
    string cmd;
    cmd = "echo 1 > ";
    cmd += op_mode_path_;
    SystemCall(cmd.c_str());
    SystemCall("ifconfig wlan0 0.0.0.0");
    SystemCall("pkill dnsmasq");
    SystemCall("ndc softap stopap");
    SystemCall("ifconfig wlan0 down");
    return 0;
}

bool WifiAp::isRunning() {
    return parseCommand("ndc softap status", "is running") == "\\true";
}

int WifiAp::reset() {
    FILE *hostcfg = fopen(conf_path_.c_str(), "w");
    fprintf(hostcfg,"interface=wlan0\n"
						"driver=nl80211\n"
						"ctrl_interface=/data/misc/wifi/hostapd\n"
						"ssid=%s\n"
						"wpa_passphrase=%s\n"
						"wpa_key_mgmt=WPA-PSK\n"
						"wpa_pairwise=TKIP\n"
						"channel=11\n"
						"auth_algs=1\n"
						"ieee80211n=1\n"
						"hw_mode=g\n"
						"ignore_broadcast_ssid=0\n"
						"wowlan_triggers=any\n"
						"wpa=3\n"
                        "rsn_pairwise=CCMP\n", default_ssid_.c_str(), default_password_.c_str());
    fclose(hostcfg);
    return 0;
}

WifiOff::WifiOff() {}
