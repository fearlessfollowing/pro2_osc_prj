//
// Created by vans on 16-12-2.
//

#ifndef INC_360PRO_SERVICE_CPP_WRAPPER_H
#define INC_360PRO_SERVICE_CPP_WRAPPER_H

#ifdef __cplusplus
extern "C"{
#endif
int send_event(void *pV);
#ifdef __cplusplus
}
#endif
#endif //INC_360PRO_SERVICE_CPP_WRAPPER_H
