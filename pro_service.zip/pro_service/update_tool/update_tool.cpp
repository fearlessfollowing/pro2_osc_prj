//
// Created by vans on 17-3-24.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/statfs.h>
#include <sys/stat.h>
#include "../ins_types.h"
#include "../msg_util.h"
#include "../sp.h"
#include "../sig_util.h"
#include "../pro_update/update_util.h"
#include "../pro_update/dbg_util.h"
#include "../md5/md5.h"

#define CHECK_EQ(a, b) \
do { \
if((a) != (b)) {\
   DBG_ERR( "CHECK_EQ(%s, %s) %d %d\n",#a, #b ,(int)a,(int)b);\
   abort();\
}\
} while(0)

#define CHECK_NOT_NULL(a) \
do { \
if((a) ==  nullptr) {\
   DBG_ERR( "CHECK_NOT_NULL(%s) is nullptr\n",#a);\
   abort();\
}\
} while(0)

void usage()
{
    printf("-c customer id(0-255)\n");
    printf("-m manufacture id(0-255)\n");
    printf("-t 0(app) or 1(rom)\n");
    printf("-e 0(unencrpt) or 1(encrpt)\n");
    printf("-k kenerl version(string)\n");
    printf("default: cid(100) mid(101) type(0) encrpyt(0)\n");
}

static void rm_update_bin()
{
    int iRet = rm_file(UPDATE_BIN_NAME);
    CHECK_EQ(iRet, 0);
}

static u32 write_update_app(FILE *fp_bin,u8 version)
{
    u32 write_update_size = 0;
    u32 file_size = get_file_size(UPDATE_APP_NAME);
//    DBG_PRINT("update app size %d\n",file_size);

    FILE *fp_read = fopen(UPDATE_APP_NAME,"rb");
    CHECK_NOT_NULL(fp_read);

    u8 file_size_bytes[4];


    char buf[1024 *1024];

    u32 read_len = 0;
    u32 write_len = 0;
    u32 read_file_len = 0;

    fseek(fp_bin,0L,SEEK_SET);
    write_len = fwrite(FP_KEY,1,strlen(FP_KEY),fp_bin);
    CHECK_EQ(write_len,strlen(FP_KEY));
    dump_bytes((u8 *)FP_KEY,write_len,"write fp key");
    write_update_size += write_len;

    write_len = fwrite(&version,1,1,fp_bin);
    CHECK_EQ(write_len,1);
    dump_bytes((u8 *)&version,1,"write version");
    write_update_size += write_len;
    printf("write version %d\n",version);

    memset(file_size_bytes,0,sizeof(file_size_bytes));
    int_to_bytes(file_size_bytes,file_size);
    write_len = fwrite(file_size_bytes,1,sizeof(file_size_bytes),fp_bin);
    CHECK_EQ(write_len,sizeof(file_size_bytes));

    write_update_size += write_len;
    memset(buf,0,sizeof(buf));

    fseek(fp_read,0L,SEEK_SET);
    while ((read_len = fread(buf, 1, sizeof(buf),fp_read)) > 0)
    {
        write_len = fwrite(buf, 1, read_len, fp_bin);
        CHECK_EQ(write_len,read_len);
        read_file_len += write_len;
        memset(buf, 0, sizeof(buf));
    }
    printf("2read_file_len %u file_size %u\n",read_file_len, file_size);

    CHECK_EQ(read_file_len,file_size);
    write_update_size += read_file_len;

    return write_update_size;
}

static void check_final_bin_size(u32 check_size)
{
//    FILE *fp_bin = fopen(UPDATE_BIN_NAME, "rb");
//    CHECK_NOT_NULL(fp_bin);
//    u32 file_len = get_file_len(fp_bin);
//    fclose(fp_bin);
//    sync();

    u32 file_len = get_file_size(UPDATE_BIN_NAME);

    msg_util::sleep_ms(1000);
    if(file_len != check_size)
    {
        DBG_ERR("check file size error file_len %u check size %u",
                file_len,check_size);
        rm_update_bin();
        abort();
    }
    else
    {
        printf("write update app suc\n");
    }
}

static int write_tail(bool bKey)
{
    return write_file_key_md5(UPDATE_BIN_NAME);
}

static u32 write_bin(UPDATE_HEADER *pstHead, const char *file_name,u8 version)
{
    //rm old update bin if exists
    rm_update_bin();

    FILE *fp_bin = fopen(UPDATE_BIN_NAME, "wb+");
    CHECK_NOT_NULL(fp_bin);

    printf("open %s suc\n",UPDATE_BIN_NAME);

    u32 update_app_size = write_update_app(fp_bin,version);

    u32 size1 = get_file_size(file_name);
    printf("%s size %u \n",file_name, size1);

    FILE *fp = fopen(file_name, "rb");
    CHECK_NOT_NULL(fp);
//        struct stat statbuf;
//        stat(file_name, &statbuf);
//        u32 size2 = statbuf.st_size;
//        printf("stat size %u \n", size2);

    printf("debug header : cid %d mid %d type %d encrpty %d kernel version %s\n",
           pstHead->cid,pstHead->mid,pstHead->update_type,
           pstHead->encrpyt, pstHead->kernel_version);

    char buf[1024 * 1024];
    u8 header_len_bytes[4];
    u32 read_len = 0;
    u32 write_len = 0;
    u32 read_file_len = 0;

    u32 packet_header_len = 0;

    u32 header_len = sizeof(UPDATE_HEADER);

    u32 content_offset = sizeof(header_len_bytes) + header_len;

    int_to_bytes(header_len_bytes,header_len);

    write_len = fwrite(header_len_bytes,1,sizeof(header_len_bytes),fp_bin);
    CHECK_EQ(write_len,sizeof(header_len_bytes));

    packet_header_len += write_len;
    dump_bytes(header_len_bytes,write_len,"write header_len_bytes");

    int_to_bytes((u8 *)pstHead->len,size1);
    u8 *header_buf = (u8 *)pstHead;

    write_len = fwrite(header_buf,1,header_len,fp_bin);
    CHECK_EQ(write_len,header_len);
    packet_header_len += write_len;
    dump_bytes(header_buf,write_len,"write header");

    printf("packet_header_len %u content_offset is ( %lu + %u) = %u\n",
           packet_header_len,sizeof(header_len_bytes),
           header_len,content_offset);

    CHECK_EQ(packet_header_len,content_offset);

    memset(buf, 0, sizeof(buf));
//            fseek(fp_bin,  content_offset, SEEK_SET);

    fseek(fp,0L,SEEK_SET);
    //write content
    while ((read_len = fread(buf, 1, sizeof(buf),fp)) > 0)
    {
        write_len = fwrite(buf, 1, read_len, fp_bin);
        CHECK_EQ(write_len,read_len);
        read_file_len +=  write_len;
        memset(buf, 0, sizeof(buf));
    }
    printf("read_file_len is %u size1 %d\n", read_file_len,size1);
    CHECK_EQ(read_file_len,size1);
            //write header_len
    fclose(fp_bin);
    fclose(fp);
    sync();
    msg_util::sleep_ms(2000);
    printf("write file len is %d\n",
           update_app_size + packet_header_len + read_file_len );

    return (update_app_size + packet_header_len + read_file_len);
}

int main(int argc, char **argv)
{
    printf("update tool\n");
    int cid = DEF_CID;
    int mid = DEF_MID;
    int ch;
    int iRet = 0;

    int type = 0;
    int encrpyt = 0;
    char k_version[512];
    bool bKey = false;
    u8 version = 100;
    u32 check_size = 0;

    registerSig(default_signal_handler);
    signal(SIGPIPE, pipe_signal_handler);

    //set k1.00 default
    snprintf(k_version,sizeof(k_version),"%s","k1.00");

    while ((ch = getopt(argc, argv, "c:m:t:k:v:hs")) != -1)
    {
        switch (ch)
        {
            case 'c':
                cid = atoi(optarg);
                break;
            case 'm':
                mid = atoi(optarg);
                break;
            case 't':
                type = atoi(optarg);
                break;
            case 'e':
                encrpyt = 1;
                break;
            case 'k':
                snprintf(k_version,sizeof(k_version),"%s", optarg);
                break;
            case 'v':
                version = atoi(optarg);
                break;
            case 's':
                printf("scramble\n");
                bKey = true;
                break;
            case 'h':
                usage();
                goto EXIT;
            default:
                printf("invalid option %s\n", optarg);
                goto EXIT;
        }
    }
    if (cid >= 0 && cid <= 255)
    {
        if (mid >= 0 && mid <= 255)
        {
            CHECK_EQ(type,0);
            if (encrpyt >= 0 && encrpyt <= 1)
            {
                const char *file_name = update_zip_name[type];
                UPDATE_HEADER stHeader;
                memset(&stHeader, 0, sizeof(UPDATE_HEADER));
                stHeader.cid = (u8) cid;
                stHeader.mid = (u8) mid;
                stHeader.update_type = (u8) type;
                stHeader.encrpyt = (u8) encrpyt;
                snprintf((char *)stHeader.kernel_version,sizeof(stHeader.kernel_version),"%s",k_version);
                check_size = write_bin(&stHeader, file_name,version);

                check_final_bin_size(check_size);
                iRet = write_tail(bKey);
                CHECK_EQ(iRet,0);
                check_final_bin_size(check_size + 32);
            }
        }
        else
        {
            printf("invalid mid %d ,pls input 0-255\n", mid);
        }
    }
    else
    {
        printf("invalid cid %d ,pls input 0-255\n", cid);
    }
//    printf("you choose %d rpm\n",astRPM[rpm_select].rmp);
EXIT:
    return iRet;
}