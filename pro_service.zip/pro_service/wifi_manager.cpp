// #include <cutils/log.h>
#include "wifi_manager.h"

WifiContext *WifiContext::sInstance = nullptr;

WifiContext *WifiContext::Instance() {
    if (!sInstance)
        sInstance = new WifiContext();
    return sInstance;
}

WifiContext::WifiContext()
:mode_(WIFI_MODE_OFF),
state_(make_shared<WifiOff>()) {
}

WifiContext::~WifiContext()
{
    state_ = nullptr;
    sInstance = nullptr;
}

int WifiContext::switchMode(WifiMode mode) {
    if (!sInstance) 
        return -1;

    if (mode == mode_)
        return 0;

    state_->stop();

    switch (mode) {
    case WIFI_MODE_OFF:
        state_ = std::make_shared<WifiOff>();
        mode_  = WIFI_MODE_OFF;
        break;
    case WIFI_MODE_STA:
        state_ = std::make_shared<WifiSta>(*sInstance);
        mode_  = WIFI_MODE_STA;
        break;
    case WIFI_MODE_AP:
        state_ = std::make_shared<WifiAp>(*sInstance);
        mode_  = WIFI_MODE_AP;
        break;
    default:
        // SLOGE("invalid mode");
        return -1;
    }
    return 0;
}

int WifiContext::start() {
    return state_->start();
}

int WifiContext::stop() {
    return state_->stop();
}

int WifiContext::setSSID(const char *str) {
    return state_->setSSID(str);
}

int WifiContext::setPassword(const char *str) {
    return state_->setPassword(str);
}

string WifiContext::getSSID() {
    return state_->getSSID();
}

string WifiContext::getPassword() {
    return state_->getPassword();
}

string WifiContext::ip() {
    return state_->ip();
}
