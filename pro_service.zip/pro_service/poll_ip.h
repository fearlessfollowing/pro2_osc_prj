//
// Created by vans on 16-12-6.
//

#ifndef PROJECT_POLL_IP_H
#define PROJECT_POLL_IP_H

enum
{
    DEV_LAN,
    DEV_WLAN,
    DEV_4G,
};



#endif //PROJECT_POLL_IP_H
