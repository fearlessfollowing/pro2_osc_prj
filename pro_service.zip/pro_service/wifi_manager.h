#ifndef __WIFI_MANAGER_H__
#define __WIFI_MANAGER_H__

#include "wifi_state.h"

using namespace std;

class WifiState;

class WifiContext {
public:
    typedef enum {
        WIFI_MODE_OFF = 0,
        WIFI_MODE_STA,
        WIFI_MODE_AP,
    }WifiMode;

private:
    WifiMode mode_;
    shared_ptr<WifiState> state_;
    static WifiContext *sInstance;
    
public:
    ~WifiContext();
    static WifiContext *Instance();

    int switchMode(WifiMode mode);
    WifiMode mode() const {
        return mode_;
    }

    shared_ptr<WifiState> state() const {
        return state_;
    }

    int start();
    int stop();
    int setSSID(const char *str);
    int setPassword(const char *str);
    string getSSID();
    string getPassword();
    string ip();

private:
    WifiContext();
};


#endif