//
// Created by vans on 16-12-2.
//

//#include "sp.h"
#include "msg_util.h"
#include "sig_util.h"
#include "arlog.h"
//#define TEST_PKILL

void start_all();
void init_fifo();
void debug_version_info();

const char *log_name = "/data/p_log";
int main(int argc ,char *argv[])
{
    debug_version_info();
    registerSig(default_signal_handler);
    signal(SIGPIPE, pipe_signal_handler);

    arlog_configure(true,true,log_name,false);
    init_fifo();
    start_all();

    while(1)
    {
        msg_util::sleep_ms(5 * 1000);
    }
    printf("main pro over\n");
}