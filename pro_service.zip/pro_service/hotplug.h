//
// Created by vans on 16-12-2.
//

#ifndef INC_360PRO_SERVICE_HOTPLUG_H
#define INC_360PRO_SERVICE_HOTPLUG_H

#ifdef __cplusplus
extern "C" {
#endif
int stop_monitor_hotplug(void);
int start_monitor_hotplug(void);
#ifdef __cplusplus
}
#endif
#endif //INC_360PRO_SERVICE_HOTPLUG_H
