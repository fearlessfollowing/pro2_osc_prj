#ifndef _GIT_VERSION_H_IN
#define _GIT_VERSION_H_IN

#define GIT_SHA1 "git: ""33a69c5f6c0c74a670006d21749a3f76690e3dba"" build: ""2018-07-09T18:55:55"
#endif
