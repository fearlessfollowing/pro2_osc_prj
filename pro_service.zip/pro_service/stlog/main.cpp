//
// Created by vans on 17-3-24.
//
#include "stlog.h"

//#define TAG ("log_test")
int main(int argc, char **argv)
{
//    Log.d(TAG,"start debug");
    return 0;
}