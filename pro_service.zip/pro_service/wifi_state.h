#ifndef __WIFI_STATE_H__
#define __WIFI_STATE_H__

#include <iostream>
#include <string>
#include <thread>
#include "wifi_manager.h"

#define LOG_TAG "InsWifiManager"

using namespace std;

class WifiContext;

class WifiState {
public:
    WifiState();
    virtual ~WifiState() = 0;

    virtual int start() = 0;
    virtual int stop() = 0;
    virtual int setSSID(const char *str) = 0;
    virtual int setPassword(const char *str) = 0;
    virtual string getSSID() = 0;
    virtual string getPassword() = 0;

    virtual string ip() = 0;

public:
    string ssid_;
    string password_;
    string mode_;
    const char *op_mode_path_ = "/sys/module/bcmdhd/parameters/op_mode";
};

class WifiSta : public WifiState {
public:
    WifiSta(WifiContext &context);
    // ~WifiSta();
    
    int start();
    int stop();

    // launch daemon
    int enable();
    int disable();
    // do connection
    int connect();
    int disconnect();

    int setSSID(const char *str);
    int setPassword(const char *str);
    int setEncryptMode(const char *mode);

    int reconnect();
    
    string getSSID() {
        return ssid_;
    }

    string getPassword() {
        return password_;
    }

    bool isConnected();

    string ip();

private:
    int cliCommand(string subcmd);

    int do_connect();
    int do_disconnect();

    int switchNetwork(int idx);

    int reset();
    bool isRunning();

public:
    bool quit_ = false;
    const string conf_path_ = "/data/misc/wifi/wpa_supplicant.conf";
    const string node_path_ = "/data/misc/wifi/sockets/";

private:
    thread ip_thread_;

    WifiContext &context_;
};

class WifiAp : public WifiState {
public: 
    typedef enum {
        AP_FREQ_2G = 0,
        AP_FREQ_5G,
    } ApFreq;

    WifiAp(WifiContext &context);

    int start();
    int stop();

    // launch daemon
    int enable();
    int disable();

    // apply at next launch
    int setSSID(const char *str);
    int setPassword(const char *str);
    int setChannel(int c);
    int setFreq(ApFreq f);

    string getSSID() {
        return ssid_;
    }

    string getPassword() {
        return password_;
    }

    string ip() {
        return ip_;
    }

private:
    int reset();
    bool isRunning();

private:
    int channel_;
    ApFreq freq_;
    const string conf_path_ = "/data/misc/wifi/hostapd.conf";
    const string node_path_ = "/data/misc/wifi/hostapd/";
    const string ip_ = "192.168.43.1";
    const string ip_range_ = "192.168.43.2,192.168.43.200";
    const string default_ssid_ = "Insta360_Pro";
    const string default_password_ = "88888888";

    WifiContext &context_;
};

class WifiOff : public WifiState {
public:
    WifiOff();

    int start() { return 0; }
    int stop() { return 0; }
    int setSSID(const char *str) { return 0; }
    int setPassword(const char *str) { return 0; }
    string getSSID() {
        return string("");
    }

    string getPassword() {
        return string("");
    }

    string ip() {
        return string("");
    }
};

#endif