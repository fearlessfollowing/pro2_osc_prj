#include <stdio.h>

#include "tx_oled.h"
#include "tx_key.h"
#include "tx_dzlib.h"


int main(int argc,char *argv[])
{
	key_event ev[3];
	
	tx_oled_init();
	
	tx_key_init();
	
	int i = 0 ,j;

	while(1)
	{
		//tx_oled_draw_icon_ex(IDX_LOGO_PHOTO_ICON);
		//tx_oled_draw_icon_ex(IDX_LOGO_READY);
		//tx_oled_draw_icon_ex(IDX_STATE_WIFI_ON);
		//tx_oled_draw_icon_ex(IDX_LOGO_BATTERY);
		//tx_oled_draw_icon_ex(IDX_STATE_LIVE_DOT);
		//tx_oled_draw_icon_ex(IDX_LOGO_LIVE_ICON);
		//tx_oled_draw_icon_ex(IDX_STATE_LOADING_DOT);
		//tx_oled_draw_icon_ex(IDX_STATE_LOADING_DOT2);
		//tx_oled_draw_icon_ex(IDX_STATE_LOADING_DOT1);
		//tx_oled_draw_icon_ex(IDX_LOGO_PHOTO_ICON);
	#if 0	
		sleep(1);
		tx_oled_draw_icon_ex(IDX_LOGO_READY);
		sleep(1);
		tx_oled_draw_icon_ex(IDX_LOGO_START);
		sleep(1);
		tx_oled_draw_icon_ex(IDX_LOGO_STORING);
		sleep(1);
		tx_oled_draw_icon_ex(IDX_LOGO_VIDEO_DOT);
		sleep(1);
		tx_oled_draw_icon_ex(IDX_LOGO_VIDO_ICON);
		sleep(1);
	#endif	
		//tx_oled_char_icon(0,0,8,48,"0:1:23456789");
		tx_oled_char_icon(0,0,8,16,"123.456.789.012");
		//tx_oled_fill(0, 0, 64, 32, 0xFF); //0x00
		//tx_oled_reset();
		memset(ev,0,sizeof(ev));
		tx_key_read(ev);
		for(j = 0; j <3 ; j++)
		{	
			printf("type = %d code = %d, value =%d\n",ev[j].type, ev[j].code, ev[j].value);
		}
		
		sleep(3);
		tx_oled_cls();
	}	
	
	tx_oled_exit();
	tx_key_exit();
	return 0;
}
