//
// Created by vans on 17-3-24.
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/statfs.h>
#include <sys/stat.h>
#include "../ins_types.h"
#include "../msg_util.h"
#include "../sp.h"
#include "../sig_util.h"
#include "update_util.h"
#include "dbg_util.h"
#include "../stlog/stlog.h"
#include "update_oled.h"
#include "../md5/md5.h"
#include "../arlog.h"

#define TAG ("update_test")

#define VERSION_STR ("V1.10")

static const char *mount_src[] =
{
        "/dev/mmcblk1",
        "/dev/block/vold",
        "/dev/sd",
};

static bool check_block_mount(char *dev)
{
    bool ret = false;
    for(u32 i = 0; i < sizeof(mount_src)/sizeof(mount_src[0]); i++)
    {
        if(strstr(dev,mount_src[i]) == dev)
        {
            ret = true;
            break;
        }
    }

    return ret;
}

static void get_update_test_version(char *ver,int len)
{
    snprintf(ver,len,"%s-%s",VERSION_STR,__DATE__);
    Log.d(TAG,"\nu version is %s",ver);
}

static const char *get_key()
{
    return FP_KEY;
}

static bool check_free_space(u32 limit)
{
    bool bAllow = false;
    struct statfs diskInfo;

    statfs(UPDATE_BASE_PATH, &diskInfo);
    u64 blocksize = diskInfo.f_bsize;    //每个block里包含的字节数
    u64 availableDisk = diskInfo.f_bavail * blocksize;   //可用空间大小
    u32 size_M = (u32) (availableDisk >> 20);

    if (size_M > limit)
    {
        bAllow = true;
    }
    else
    {
        Log.e(TAG,"update no space free size_M %u limit %u",
                size_M, limit);
    }
    return bAllow;
}


static const UPDATE_FILES mUpdateApps[] =
{
        {UPDATE_APP_BIN_FULL_NAME, DEST_BIN_PATH"update_app"},
};

static bool update_update_app_zip()
{
    bool bRet = true;
    if(remount_sys() == 0)
    {
        for (u32 i = 0; i < sizeof(mUpdateApps) / sizeof(mUpdateApps[0]); i++)
        {
            if (update_item(mUpdateApps[i].src,mUpdateApps[i].dest) != 0)
            {
                if(i == 0)
                {
                    Log.e(TAG,"no %s found",mUpdateApps[i].src);
                    bRet = false;
                    break;
                }
            }
        }
    }
    if(!bRet)
    {
        disp_update_error(ERR_GET_APP);
    }
    else
    {
        msg_util::sleep_ms(10);
    }
    return bRet;
}

static int check_version(u8 new_version)
{
    u8 old_version;
    int bRet = 0;
    if(check_path_exist(VER_FULL_PATH))
    {
        FILE *fp = fopen(VER_FULL_PATH,"rb");
        if(fp)
        {
            char buf[128];
            u32 read_len;

            read_len = fread(buf,1,sizeof(buf),fp);
//            Log.e(TAG,"read version file len %d",read_len);
            if(read_len > 0)
            {
                old_version = atoi(buf);
                if(new_version <= old_version)
                {
                    Log.d(TAG,"v old (%d %d)",
                              new_version,old_version);
                    bRet = 2;
                }
            }
            else
            {
            //if empty still update or read fail
            }
            fclose(fp);
        }
        else
        {
            Log.e(TAG,"open %s fail",VER_FULL_PATH);
            disp_update_error(ERR_OPEN_VER);
            bRet = -1;
        }
    }
//    else
//    {
//        //if not exist ,go on update
//        Log.e(TAG,"no %s exist",VER_FULL_PATH);
//    }

    return bRet;
}

static int get_update_app()
{
    int bRet = -1;
    FILE *fp = nullptr;
    u8 buf[1024 * 1024];
    const char *key = get_key();
    u32 update_app_len;
    u32 read_len;

    if(!check_file_key_md5(UPDATE_BIN_FULL_NAME))
    {
        Log.e(TAG,"err check file %s ",
                UPDATE_BIN_FULL_NAME);
        disp_update_error(ERR_CHECK);
        goto EXIT;
    }

    fp = fopen(UPDATE_BIN_FULL_NAME, "rb");
    if (!fp)
    {
        Log.e(TAG,"open pro_update %s fail", UPDATE_BIN_FULL_NAME);
        disp_update_error(ERR_OPEN_FULL_BIN);
        goto EXIT;
    }

//    bin_file_size = get_file_len(fp);
//    if (!check_free_space((u32)((bin_file_size * 5) >> 20)))
//    {
//        disp_update_error(ERR_SPACE_LIMIT);
//        goto EXIT;
//    }

    memset(buf, 0, sizeof(buf));
    fseek(fp, 0L, SEEK_SET);
    read_len = fread(buf, 1, strlen(key), fp);
    if (read_len != strlen(key))
    {
        Log.e(TAG,"read key len mismatch(%u %zd)",
                read_len, strlen(key));
        disp_update_error(ERR_READ_KEY);
        goto EXIT;
    }
    dump_bytes(buf, read_len, "read key");
    if (strcmp((const char *) buf, key) != 0)
    {
        Log.e(TAG,"key mismatch(%s %s)", key, buf);
        disp_update_error(ERR_KEY_MISMATCH);
        goto EXIT;
    }

    memset(buf, 0, sizeof(buf));
    read_len = fread(buf, 1, VERSION_LEN, fp);
    if (read_len != VERSION_LEN)
    {
        Log.e(TAG,"read version len mismatch(%u 1)",
                read_len);
        disp_update_error(ERR_READ_VER_LEN);
        goto EXIT;
    }
    dump_bytes(buf, read_len, "read version");
//    Log.d(TAG,"rom version %d",buf[0]);
    bRet = check_version(buf[0]);
    if(bRet != 0)
    {
        goto EXIT;
    }
//    disp_update_info(START_CHECK);
    //when version match,disp check
    memset(buf, 0, sizeof(buf));
    read_len = fread(buf, 1, UPDATE_APP_CONTENT_LEN, fp);
    //go on
    if (read_len != UPDATE_APP_CONTENT_LEN)
    {
        disp_update_error(ERR_READ_APP_LEN);
        Log.e(TAG,"update app len mismatch(%d %d)", read_len, UPDATE_APP_CONTENT_LEN);
        goto EXIT;
    }
    dump_bytes(buf, read_len, "read update app header len");
    update_app_len = bytes_to_int(buf);
//    Log.d(TAG,"update app header len %d", update_app_len);

    if (gen_file(UPDATE_APP_FULL_ZIP, update_app_len, fp))
    {
        if (tar_zip(UPDATE_APP_FULL_ZIP) == 0)
        {
            if(update_update_app_zip())
            {
                bRet = 0;
            }
        }
        else
        {
            disp_update_error(ERR_TAR_APP_ZIP);
        }
    }
    else
    {
        disp_update_error(ERR_GET_APP_ZIP);
    }
EXIT:
    if (fp)
    {
        fclose(fp);
    }
    return bRet;
}

static int read_line(int fd, void *vptr, int maxlen)
{
    int n, rc;
    char c;
    char *ptr;

    ptr = (char *)vptr;
    for (n = 1; n < maxlen; n++)
    {
        again:
        if ((rc = read(fd, &c, 1)) == 1)
        {
            //not add '\n' to buf
            if (c == '\n')
                break;
            *ptr++ = c;

        }
        else if (rc == 0)
        {
            *ptr = 0;
            return (n - 1);
        }
        else
        {
            if (errno == EINTR)
            {
                Log.d(TAG,"read line error\n");
                goto again;
            }
            return -1;
        }
    }
    *ptr = 0;
    return(n);
}

static bool get_update_path(char *path,u32 len)
{
    bool bRet = false;
    int max_times = 3;

    for (int i = 0; i < max_times; i++)
    {
        int fd = open("/proc/mounts",O_RDONLY);
        if(fd > 0)
        {
            char buf[1024];
            int iLen = -1;
            char *delim = (char *)" ";

            memset(buf, 0, sizeof(buf));
            while ((iLen = read_line(fd, buf, sizeof(buf))) > 0)
            {
                char *p = strtok(buf, delim);
                if (p != nullptr)
                {
                    if (check_block_mount(p))
                    {
//                        Log.d(TAG,"block dev name %s", p);
                        p = strtok(NULL, delim);
                        if (p)
                        {
                            snprintf(path, len, "%s", p);
                            bRet = true;
//                            Log.d(TAG,"get_update_path suc i %d",i);
                            goto EXIT;
                        }
                        else
                        {
                            Log.d(TAG,"no mount path?\n");
                        }
                    }
                }
                memset(buf, 0, sizeof(buf));
            }
            close(fd);
        }
        msg_util::sleep_ms(2000);
    }
EXIT:
    return bRet;
}

//static void move_bin(const char *org, const char *path,const char *dest)
//{
//    char buf[1024];
//
//    snprintf(buf,sizeof(buf),"%s%s",org,dest);
//
//    printf("mv cmd %s ",buf);
//    exec_sh(buf);
//}

int main(int argc, char **argv)
{
    int iRet = -1;
    bool found_update = false;
    char src[1024];
    char mount_path[1024];

    char version_dbg[512];

    registerSig(default_signal_handler);
    signal(SIGPIPE, pipe_signal_handler);

    arlog_configure(true,true,log_name,false);
    get_update_test_version(version_dbg,sizeof(version_dbg));
//#ifdef ENABLE_PKILL
//    //confirm update_app not run
//        const char *app_list[] = {"update_app","pro_service", "python3.5","camerad","rtmpd","mongoose"};
//        for(u32 i = 0; i < sizeof(app_list)/sizeof(app_list[0]);i++)
//        {
//            Log.d(TAG,"pkill app [%d]",i);
//            if(kill_app(app_list[i]) == 0)
//            {
//                Log.d(TAG,"%s running",app_list[i]);
//            }
//            msg_util::sleep_ms(2000);
//        }
//#endif
    // need recover from last update fail
    if(check_path_exist(UPDATE_BIN_FULL_NAME))
    {
        snprintf(src, sizeof(src), "%s",UPDATE_BIN_FULL_NAME);
        snprintf(mount_path,sizeof(mount_path),"%s",UPDATE_BASE_PATH);
        Log.d(TAG,"found r from last update");
        init_oled_module();

        //remove bat check in update_test 0626
//        if(!is_bat_enough())
//        {
//            Log.d(TAG,"bat less a\n");
//            goto START_APP;
//        }
//        else
        {
            found_update = true;
        }
        // no need check free space for already check in last fail update
    }
    else if(get_update_path(mount_path,sizeof(mount_path)))
    {
        snprintf(src, sizeof(src), "%s/%s", mount_path, UPDATE_BIN_NAME);
        if (!check_path_exist(src))
        {
            Log.d(TAG,"a no %s found", src);
            iRet = 0;
            goto START_APP;
        }
        else
        {
            //remove bat check in update_test 0626
//            if(!is_bat_enough())
//            {
//                Log.d(TAG,"bat less b\n");
//                goto START_APP;
//            }
//            else
//            {
//                found_update = true;
//            }
            init_oled_module();
            u32 bin_file_size = get_file_size(src);
            if (!check_free_space((u32)((bin_file_size * 5) >> 20)))
            {
                strcat(mount_path,UPDATE_BIN_FAIL1);
                move_bin(src,mount_path);
                disp_update_error(ERR_SPACE_LIMIT);
                goto EXIT;
            }
            Log.d(TAG," found update file %s", src);
            //change from update_item to update_sd_item avoiding sd plugged in with write protection 170712
            if(update_sd_item(src,UPDATE_BIN_FULL_NAME) != 0)
            {
                strcat(mount_path,UPDATE_BIN_FAIL2);
                move_bin(src,mount_path);
                Log.e(TAG,"2 update item %s fail",src);
                disp_update_error(ERR_CP_UPDATE_BIN);
                goto EXIT;
            }
            else
            {
                sync();
                msg_util::sleep_ms(100);
                if (!check_path_exist(UPDATE_BIN_FULL_NAME))
                {
                    Log.e(TAG," cp or mv %s suc but no access",
                            UPDATE_BIN_FULL_NAME);
                    strcat(mount_path,UPDATE_BIN_FAIL3);
                    move_bin(src,mount_path);;
                    disp_update_error(ERR_ACCESS_UPDATE_BIN);
                }
                else
                {
                    found_update = true;
                }
            }
        }
    }
    else
    {
        Log.d(TAG,"b no %s found", UPDATE_BIN_FULL_NAME);
        goto START_APP;
    }
    if(found_update)
    {
//       Log.d(TAG," cp %s suc to update",src);
        iRet = get_update_app();
        if (iRet == 0)
        {
            const char *pro_bin = "/system/bin/update_app";
            deinit_oled_module();
            iRet = exec_sh(pro_bin);
            Log.d(TAG,"exec_sh ret %d",iRet);
            if (iRet != 0)
            {
                //reinit oled to disp oled
                Log.e(TAG,"execute %s fail", pro_bin);
                strcat(mount_path,UPDATE_BIN_FAIL4);
                move_bin(src,mount_path);
            }
            rm_file("/system/bin/update_app");
        }
            //same version
        else if(iRet == 2)
        {
            rm_file(UPDATE_BIN_FULL_NAME);
            deinit_oled_module();
//            strcat(mount_path,UPDATE_BIN_UPDATED);
//            move_bin(src,mount_path);
            goto START_APP;
        }
        else
        {
            Log.e(TAG,"get_update_app fail\n");
            strcat(mount_path,UPDATE_BIN_FAIL5);
            move_bin(src,mount_path);
            rm_file(UPDATE_BIN_FULL_NAME);
        }
    }
EXIT:
    Log.d(TAG,"2u over ret %d", iRet);
    arlog_close();
    if(iRet != 0)
    {
        start_reboot();
    }
    else
    {
#ifdef SUC_REBOOT
        start_reboot();
#else
        start_app_directly();
#endif
    }
    return iRet;
START_APP:
    arlog_close();
    start_app_directly();
    return 0;
}