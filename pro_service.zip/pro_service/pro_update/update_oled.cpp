//
// Created by vans on 17-5-2.
//
#include "../include_common.h"
#include "../oled_module.h"
#include "update_oled.h"

static oled_module *mOLEDModule = nullptr;
typedef struct _oled_str_
{
    int type;
    const char * str;
}OLED_STR;

static OLED_STR mSysStr[] =
{
        {START_CHECK,"check..."},
        //disp in update_test
        {ERR_CP_UPDATE_BIN,"701"},
        {ERR_ACCESS_UPDATE_BIN,"702"},
        {ERR_OPEN_FULL_BIN,"703"},
        {ERR_SPACE_LIMIT,"704"},
        {ERR_CHECK,"705"}, //md5
        {ERR_READ_KEY,"706"},
        {ERR_KEY_MISMATCH,"707"},
        {ERR_CHECK_VERSION,"708"},
        {ERR_READ_APP_LEN,"709"},
        {ERR_GET_APP_ZIP,"710"},
        {ERR_TAR_APP_ZIP,"711"},
        {ERR_GET_APP,"712"},
        {ERR_EXEC_APP,"713"},
        {CHECK_FAIL,"714"},
        {ERR_READ_VER_LEN,"715"},
        {ERR_OPEN_VER,"716"},
        //disp in app
        {ERR_APP_HEADER_MID_MISMATCH,"801"},
        {ERR_APP_HEADER_CID_MISMATCH,"802"},
        {ERR_APP_READ_APP_CONTENT,"803"},
        {ERR_APP_READ_HEADER_LEN,"804"},
        {ERR_APP_HEADER_LEN_MISMATCH1,"805"},
        {ERR_APP_HEADER_LEN_MISMATCH2,"806"},
        {ERR_APP_TAR_ZIP,"807"},
        {ERR_APP_GEN_ZIP,"808"},
        {ERR_APP_OPEN_BIN,"809"},
        {ERR_APP_CHMOD_PYTHON,"810"},
        {ERR_UPDATE_PYTHON,"811"},
        {ERR_UPDATE_WS,"812"},
        {ERR_UPDATE_P,"813"},
        {ERR_UPDATE_C,"814"},
        {ERR_UPDATE_MONGO,"815"},
        {ERR_UPDATE_F,"816"},
        {ERR_UPDATE_IPERF,"817"},
//        {ERR_UPDATE_GPIO_TEST,"818"},
        {ERR_UPDATE_INIT_APPN,"819"},
        {ERR_UPDATE_START_WS,"820"},
        {ERR_UPDATE_AP,"821"},
        {ERR_UPDATE_IP_SO,"822"},
        {ERR_UPDATE_I2C,"823"},
        {ERR_UPDATE_GPIO_SO,"824"},
        {ERR_UPDATE_DEF_CFG,"825"},
        {ERR_UPDATE_USER_CF,"826"},
        {ERR_UPDATE_V,"827"},
        {ERR_NO_REQUIRE,"829"},
        {ERR_UPDATE_INIT_MBX,"830"},
        {ERR_UPDATE_INIT_MBX_NEW,"831"},
        {ERR_UPDATE_UPDATE_TEST,"832"},
        {ERR_UPDATE_LOG_SO,"833"},
        {ERR_UPDATE_PKILL_ALL,"834"},
        {ERR_UPDATE_WAV,"835"},
        {ERR_UPDATE_MCFG,"836"},
        {ERR_UPDATE_MSND,"837"},
        {ERR_UPDATE_WIFI_CF,"838"},
        {ERR_UPDATE_PRO_P,"839"},
        {ERR_UPDATE_HW_STIME,"840"},
        {ERR_UPDATE_B_V,"841"},
        {ERR_UPDATE_BUILDP,"842"},
        {ERR_UPDATE_SERVICE_JAR,"843"},
        {ERR_UPDATE_MEDIA_P_APK,"844"},
        {ERR_MV_DNSMASQ,"845"},
        {ERR_UPDATE_XUSB,"846"},
        {ERR_UPDATE_FSTRIM,"847"},
        {ERR_MV_MKEFS,"848"},
        {ERR_UPDATE_VOLD,"849"},
        {ERR_STOP_VOLD,"850"},
        {ERR_MV_VOLD_TMP,"851"},
        {ERR_MV_VOLD,"852"},
        {ERR_START_VOLD,"853"},
        {ERR_CHMOD_VOLD_X,"854"},
        {ERR_UPDATE_MON_P,"855"},
        {ERR_MV_MKEFS_TMP,"856"},
        {ERR_MV_DNSMASQ_TMP,"857"},
        {ERR_CHMOD_VOLD,"858"},
        {ERR_CHMOD_MKEFS,"859"},
        {ERR_CHMOD_DNSMAQ,"860"},
        //error 9XX
        {ERR_UPDATE_AV_CODEC,"901"},
        {ERR_UPDATE_CV_LIB,"902"},
        {ERR_UPDATE_CV_V_IO,"903"},
        {ERR_UPDATE_AV_F,"904"},
        {ERR_UPDATE_CV_CORE,"905"},
        {ERR_UPDATE_CV_V,"906"},
        {ERR_UPDATE_AV_UTIL,"907"},
        {ERR_UPDATE_CV_FEAFURE,"908"},
        {ERR_UPDATE_SPE,"909"},
        {ERR_UPDATE_LIB_CAL,"910"},
        {ERR_UPDATE_CV_FLAN,"911"},
        {ERR_UPDATE_SW_SCA,"912"},
        {ERR_UPDATE_LIB_EV,"913"},
        {ERR_UPDATE_CV_HUI,"914"},
        {ERR_UPDATE_TURBO,"915"},
        {ERR_UPDATE_GYRO,"916"},
        {ERR_UPDATE_CV_CODEC,"917"},
        {ERR_UPDATE_LIB_USB,"918"},
        {ERR_UPDATE_ICONV,"919"},
        {ERR_UPDATE_IMGPROC,"920"},
        {ERR_UPDATE_LIB_ZBAR,"921"},
        {ERR_UPDATE_LIB_KEY,"922"},
        {ERR_UPDATE_LIB_CV_ML,"923"},
        {ERR_UPDATE_LIB_LED,"924"},
        {ERR_UPDATE_LIB_CV_DETECT,"925"},
//        {ERR_UPDATE_F_TEST,"926"},
        {ERR_UPDATE_APPE,"927"},
        {ERR_UPDATE_MSGCLIENT,"928"},
        {ERR_UPDATE_RTMPD,"929"},
        {ERR_UPDATE_RTMP_CRT,"930"},
        {ERR_UPDATE_RTMP_KEY,"931"},
        {ERR_UPDATE_CAMCONFIG,"932"},
        {ERR_UPDATE_RTMP_LUA,"933"},
        {ERR_UPDATE_GYRO_UPDATE,"935"},
        {ERR_UPDATE_UPGRADE_MODULE,"936"},
        {ERR_UPDATE_UPGRADE_MOD_SO,"937"},
        {ERR_UPDATE_LIB_CU_F,"938"},
        {ERR_UPDATE_LIB_CU_I,"939"},
        {ERR_UPDATE_LIB_CV_PHO,"940"},
        {ERR_UPDATE_LIB_CU_L,"941"},
        {ERR_UPDATE_LIB_CV_SHA,"942"},
        {ERR_UPDATE_LIB_CU_BJD,"943"},
        {ERR_UPDATE_LIB_CV_STI,"944"},
        {ERR_UPDATE_LIB_CUDOPT,"945"},
        {ERR_UPDATE_LIB_CV_SUPERES,"946"},
        {ERR_UPDATE_LIB_CU_STEREO,"947"},
        {ERR_UPDATE_LIB_CV_WARP,"948"},
        {ERR_UPDATE_LIB_JPEG,"949"},
        {ERR_UPDATE_LIB_CUDEV,"950"},
        {ERR_UPDATE_LIB_STI,"951"},
        {ERR_UPDATE_LIB_CU_AA,"952"},
        {ERR_UPDATE_LIB_CU_AB,"953"},
        {ERR_UPDATE_LIB_CU_ACODEC,"954"},
        {ERR_UPDATE_LIB_CU_A_F,"955"},
        {ERR_UPDATE_MODULE_TOOL,"956"},
        {ERR_UPDATE_GYRO_NEW,"957"},
        {ERR_UPDATE_LIB_TW_CAPTURE,"958"},
        {ERR_UPDATE_NOISE1,"959"},
        {ERR_UPDATE_NOISE2,"960"},
        {ERR_UPDATE_FANLESS_NOISE1,"961"},
        {ERR_UPDATE_FANLESS_NOISE2,"962"},
        {ERR_UPDATE_LIB_ULBOX,"963"},
        {ERR_UPDATE_TEST_GPIO,"964"},
        {ERR_UPDATE_LIB_X264,"965"},

        {ERR_UPDATE_LIB_LEVELDB,"966"},
        {ERR_UPDATE_LIB_STAGEFRIGHT,"967"},
        {ERR_UPDATE_LIB_TIFF,"968"},

        //A12 err
        {ERR_UPDATE_A12_VER,"601"},
        {ERR_UPDATE_A12_BIN,"602"},
        {ERR_READ_A12_VER,"603"},
        {ERR_GET_A12_VER,"604"},
        {ERR_READ_A12_RES,"605"},
        {ERR_OPEN_A12_RES,"606"},
        {ERR_GET_A12_DES,"607"},
        {ERR_A12_RSP,"608"},
        {ERR_UPDATE_A,"699"},
        //update over
        {ERR_UPDATE_BACKUP,"1002"},
        {ERR_CP_RECOVER,"1003"},
        {ERR_FOUND_BACKUP,"1004"},
};

void init_oled_module()
{
    CHECK_EQ(mOLEDModule,nullptr);
    mOLEDModule = new oled_module();
    CHECK_NE(mOLEDModule,nullptr);
    if(UPDATE_MAX != sizeof(mSysStr)/sizeof(mSysStr[0]))
    {
        printf("ERROR debug sys str num %zd UPDATE_MAX %d\n",
               sizeof(mSysStr)/sizeof(mSysStr[0]),
               UPDATE_MAX);
        bool bFound = false;
        for(u32 j = 0; j < UPDATE_MAX; j++)
        {
            bFound = false;
            for(u32 i = 0; i < sizeof(mSysStr)/sizeof(mSysStr[0]); i++)
            {
                if(mSysStr[i].type == (int)j)
                {
                    bFound = true;
                    break;
                }
            }
            if(!bFound)
            {
                printf("%d not found",j);
            }
        }
        abort();
    }
    msg_util::sleep_ms(1000);
}

void deinit_oled_module()
{
    if(mOLEDModule)
    {
        delete mOLEDModule;
        mOLEDModule = nullptr;
        msg_util::sleep_ms(2000);
    }
}

static void disp_update_str(const u8 *str,const u8 x,const u8 y)
{
    CHECK_NE(mOLEDModule, nullptr);
    mOLEDModule->ssd1306_disp_16_str(str,x,y);
}

void disp_update_icon(unsigned int icon_enum)
{
    CHECK_NE(mOLEDModule, nullptr);
    mOLEDModule->disp_icon(icon_enum);
}

void disp_update_info(int type)
{
    u32 i;
    for( i = 0; i <= sizeof(mSysStr)/sizeof(mSysStr[0]);i++)
    {
        if(type == mSysStr[i].type)
        {
//            Log.e(TAG,"mSysStr[%d].str is %s\n",i, mSysStr[i].str);
            mOLEDModule->clear_area(0,16,128,16);
            disp_update_str((const u8 *)mSysStr[i].str,20,16);
            break;
        }
    }
//    if(i == sizeof(mSysStr)/sizeof(mSysStr[0]))
//    {
//        Log.e(TAG,"not found info[%d] UPDATE_MAX %zd %d",i,
//               sizeof(mSysStr)/sizeof(mSysStr[0]), UPDATE_MAX);
//    }
}

void disp_update_err_str(const char *str)
{
    mOLEDModule->clear_area(0,0);
    disp_update_str((const u8 *)"Upgrade Fail",20,16);
    disp_update_str((const u8 *)str,20,32);
    msg_util::sleep_ms(2000);
}

void disp_update_error(int type)
{
    mOLEDModule->clear_area(0,0);
    disp_update_str((const u8 *)"Upgrade Fail",10,16);
    for(u32 i = 0; i <= sizeof(mSysStr)/sizeof(mSysStr[0]);i++)
    {
        if(type == mSysStr[i].type)
        {
            disp_update_str((const u8 *)mSysStr[i].str,55,32);
            msg_util::sleep_ms(2000);
            break;
        }
    }
}

void disp_start_boot()
{
    int times = 3;
    char buf[128];

    while(times > 0)
    {
        snprintf(buf,sizeof(buf),"boot in %ds",times);
        disp_update_str((const u8 *)buf,20,48);
        msg_util::sleep_ms(1000);
        times--;
    }
    deinit_oled_module();
}

void disp_start_reboot()
{
    int times = 9;

    char buf[128];

    while(times > 0)
    {
        snprintf(buf,sizeof(buf),"reboot in %ds",times);
        disp_update_str((const u8 *)buf,20,48);
        msg_util::sleep_ms(1000);
        times--;
    }
    deinit_oled_module();
}

void debug_oled()
{

}