
#ifndef _MODULE_UPGRADE_H_
#define _MODULE_UPGRADE_H_

#include <string>

//0 : success 
//<0 : fail
int module_upgrade(std::string path);
#endif