
//
// Created by vans on 17-4-19.
//

#include "../include_common.h"
#include "../sp.h"
#include "../sig_util.h"
#include "../check.h"
#include "update_util.h"
#include "dbg_util.h"
#include "update_oled.h"
#include "../icon_ascii.h"
#include "../arlog.h"

#define WS_SRC_INDEX (2)
#define TAG ("update_test")
enum
{
    COPY_UPDAE,
    DIRECT_UPDATE,
    ERROR_UPDATE,
};

//update after a12
static const UPDATE_FILES mUpdateRequires[] =
{
        {UPDATE_PATH_H"ws_src","/system/python/prog/",ERR_UPDATE_WS},
        {UPDATE_PATH_P"pro_service", DEST_BIN_PATH"pro_service", ERR_UPDATE_P},
        {UPDATE_PATH_P"pro_p", DEST_BIN_PATH"pro_p", ERR_UPDATE_PRO_P},
        {UPDATE_PATH_P"mon_p", DEST_BIN_PATH"mon_p", ERR_UPDATE_MON_P},
        {UPDATE_PATH_C"camerad",DEST_BIN_PATH"camerad", ERR_UPDATE_C},
        {UPDATE_PATH"pro_version",VER_FULL_PATH, ERR_UPDATE_V},
};

static const UPDATE_FILES mUpdateOthers[] =
{
        {UPDATE_PATH_P"mongoose", DEST_BIN_PATH"mongoose",ERR_UPDATE_MONGO},
        {UPDATE_PATH_P"fstrim", DEST_BIN_PATH"fstrim",ERR_UPDATE_FSTRIM},
        {UPDATE_PATH_P"fan_control",  DEST_BIN_PATH"fan_control",ERR_UPDATE_F},
        {UPDATE_PATH_P"init.mbx.sh", DEST_BIN_PATH"init.mbx.sh", ERR_UPDATE_INIT_MBX},
        {UPDATE_PATH_P"init.mcfg.sh", DEST_BIN_PATH"init.mcfg.sh", ERR_UPDATE_MCFG},
        {UPDATE_PATH_P"init.msnd.sh", DEST_BIN_PATH"init.msnd.sh", ERR_UPDATE_MSND},
        {UPDATE_PATH_P"init.mbx_new.sh", DEST_BIN_PATH"init.mbx_new.sh", ERR_UPDATE_INIT_MBX_NEW},
        {UPDATE_PATH_P"pkill_all.sh", DEST_BIN_PATH"pkill_all.sh", ERR_UPDATE_PKILL_ALL},
        {UPDATE_PATH_P"update_test", DEST_BIN_PATH"update_test_new", ERR_UPDATE_UPDATE_TEST},
        {UPDATE_PATH_P"iperf3", DEST_BIN_PATH"iperf3", ERR_UPDATE_IPERF},
        {UPDATE_PATH_P"init.appn.sh", DEST_BIN_PATH"init.appn.sh",ERR_UPDATE_INIT_APPN},
        {UPDATE_PATH_P"start_ws.sh",  DEST_BIN_PATH"start_ws.sh",ERR_UPDATE_START_WS},
        {UPDATE_PATH_P"libsoftap.so", DEST_LIB64_PATH"libsoftap.so",ERR_UPDATE_AP},
        {UPDATE_PATH_P"libiperf.so", DEST_LIB64_PATH"libiperf.so",ERR_UPDATE_IP_SO},
        {UPDATE_PATH_P"libi2c.so", DEST_LIB64_PATH"libi2c.so",ERR_UPDATE_I2C},
        {UPDATE_PATH_P"libgpio.so", DEST_LIB64_PATH"libgpio.so",ERR_UPDATE_GPIO_SO},
        {UPDATE_PATH_P"libins_log.so", DEST_LIB64_PATH"libins_log.so",ERR_UPDATE_LOG_SO},
        {UPDATE_PATH_P"def_cfg", "/data/etc/def_cfg",ERR_UPDATE_DEF_CFG},
        {UPDATE_PATH_P"user_cfg", "/data/etc/user_cfg",ERR_UPDATE_USER_CF},
        {UPDATE_PATH_P"hwSetTime", DEST_BIN_PATH"hwSetTime",ERR_UPDATE_HW_STIME},
        {UPDATE_PATH"pro_build_version",VER_BUILD_PATH, ERR_UPDATE_B_V},
        //so
        {UPDATE_PATH_C"libavcodec-56.so", DEST_LIB64_PATH"libavcodec-56.so",ERR_UPDATE_AV_CODEC},
        {UPDATE_PATH_C"libopencv_calib3d.so",DEST_LIB64_PATH"libopencv_calib3d.so",ERR_UPDATE_CV_LIB},
        {UPDATE_PATH_C"libopencv_videoio.so",DEST_LIB64_PATH"libopencv_videoio.so",ERR_UPDATE_CV_V_IO},
        {UPDATE_PATH_C"libavformat-56.so",DEST_LIB64_PATH"libavformat-56.so",ERR_UPDATE_AV_F},
        {UPDATE_PATH_C"libopencv_core.so",DEST_LIB64_PATH"libopencv_core.so",ERR_UPDATE_CV_CORE},
        {UPDATE_PATH_C"libopencv_video.so",DEST_LIB64_PATH"libopencv_video.so",ERR_UPDATE_CV_V},
        {UPDATE_PATH_C"libavutil-54.so",DEST_LIB64_PATH"libavutil-54.so",ERR_UPDATE_AV_UTIL},
        {UPDATE_PATH_C"libopencv_features2d.so",DEST_LIB64_PATH"libopencv_features2d.so",ERR_UPDATE_CV_FEAFURE},
        {UPDATE_PATH_C"libspeex.so",DEST_LIB64_PATH"libspeex.so",ERR_UPDATE_SPE},
        {UPDATE_PATH_C"libcalibration.so",DEST_LIB64_PATH"libcalibration.so",ERR_UPDATE_LIB_CAL},
        {UPDATE_PATH_C"libopencv_flann.so",DEST_LIB64_PATH"libopencv_flann.so",ERR_UPDATE_CV_FLAN},
        {UPDATE_PATH_C"libswscale-3.so",DEST_LIB64_PATH"libswscale-3.so",ERR_UPDATE_SW_SCA},
        {UPDATE_PATH_C"libev.so",DEST_LIB64_PATH"libev.so",ERR_UPDATE_LIB_EV},
        {UPDATE_PATH_C"libopencv_highgui.so",DEST_LIB64_PATH"libopencv_highgui.so",ERR_UPDATE_CV_HUI},
        {UPDATE_PATH_C"libturbojpeg.so",DEST_LIB64_PATH"libturbojpeg.so",ERR_UPDATE_TURBO},
        {UPDATE_PATH_C"libgyro2.0.so",DEST_LIB64_PATH"libgyro2.0.so",ERR_UPDATE_GYRO},
        {UPDATE_PATH_C"libgyro3.0.so",DEST_LIB64_PATH"libgyro3.0.so",ERR_UPDATE_GYRO_NEW},
        {UPDATE_PATH_C"libopencv_imgcodecs.so",DEST_LIB64_PATH"libopencv_imgcodecs.so",ERR_UPDATE_CV_CODEC},
        {UPDATE_PATH_C"libusb1.0.so",DEST_LIB64_PATH"libusb1.0.so",ERR_UPDATE_LIB_USB},
        {UPDATE_PATH_C"libiconv.so",DEST_LIB64_PATH"libiconv.so",ERR_UPDATE_ICONV},
        {UPDATE_PATH_C"libopencv_imgproc.so",DEST_LIB64_PATH"libopencv_imgproc.so",ERR_UPDATE_IMGPROC},
        {UPDATE_PATH_C"libzbar.so",DEST_LIB64_PATH"libzbar.so",ERR_UPDATE_LIB_ZBAR},
//        {UPDATE_PATH_C"libkey.so",DEST_LIB64_PATH"libkey.so",ERR_UPDATE_LIB_KEY},
        {UPDATE_PATH_C"libopencv_ml.so",DEST_LIB64_PATH"libopencv_ml.so",ERR_UPDATE_LIB_CV_ML},
//        {UPDATE_PATH_C"libled.so",DEST_LIB64_PATH"libled.so",ERR_UPDATE_LIB_LED},
        {UPDATE_PATH_C"libopencv_objdetect.so",DEST_LIB64_PATH"libopencv_objdetect.so",ERR_UPDATE_LIB_CV_DETECT},

        {UPDATE_PATH_C"libopencv_cudafilters.so",DEST_LIB64_PATH"libopencv_cudafilters.so",ERR_UPDATE_LIB_CU_F},
        {UPDATE_PATH_C"libopencv_cudaimgproc.so",DEST_LIB64_PATH"libopencv_cudaimgproc.so",ERR_UPDATE_LIB_CU_I},
        {UPDATE_PATH_C"libopencv_photo.so",DEST_LIB64_PATH"libopencv_photo.so",ERR_UPDATE_LIB_CV_PHO},
        {UPDATE_PATH_C"libopencv_cudalegacy.so",DEST_LIB64_PATH"libopencv_cudalegacy.so",ERR_UPDATE_LIB_CU_L},
        {UPDATE_PATH_C"libopencv_shape.so",DEST_LIB64_PATH"libopencv_shape.so",ERR_UPDATE_LIB_CV_SHA},
        {UPDATE_PATH_C"libopencv_cudaobjdetect.so",DEST_LIB64_PATH"libopencv_cudaobjdetect.so",ERR_UPDATE_LIB_CU_BJD},
        {UPDATE_PATH_C"libopencv_stitching.so",DEST_LIB64_PATH"libopencv_stitching.so",ERR_UPDATE_LIB_CV_STI},
        {UPDATE_PATH_C"libopencv_cudaoptflow.so",DEST_LIB64_PATH"libopencv_cudaoptflow.so",ERR_UPDATE_LIB_CUDOPT},
        {UPDATE_PATH_C"libopencv_superres.so",DEST_LIB64_PATH"libopencv_superres.so",ERR_UPDATE_LIB_CV_SUPERES},
        {UPDATE_PATH_C"libopencv_cudastereo.so",DEST_LIB64_PATH"libopencv_cudastereo.so",ERR_UPDATE_LIB_CU_STEREO},
        {UPDATE_PATH_C"libopencv_cudawarping.so",DEST_LIB64_PATH"libopencv_cudawarping.so",ERR_UPDATE_LIB_CV_WARP},
        {UPDATE_PATH_C"libjpeg.so",DEST_LIB64_PATH"libjpeg.so",ERR_UPDATE_LIB_JPEG},
        {UPDATE_PATH_C"libopencv_cudev.so",DEST_LIB64_PATH"libopencv_cudev.so",ERR_UPDATE_LIB_CUDEV},
        {UPDATE_PATH_C"libstitch.so",DEST_LIB64_PATH"libstitch.so",ERR_UPDATE_LIB_STI},
        {UPDATE_PATH_C"libopencv_cudaarithm.so",DEST_LIB64_PATH"libopencv_cudaarithm.so",ERR_UPDATE_LIB_CU_AA},
        {UPDATE_PATH_C"libopencv_cudabgsegm.so",DEST_LIB64_PATH"libopencv_cudabgsegm.so",ERR_UPDATE_LIB_CU_AB},
        {UPDATE_PATH_C"libopencv_cudacodec.so",DEST_LIB64_PATH"libopencv_cudacodec.so",ERR_UPDATE_LIB_CU_ACODEC},
        {UPDATE_PATH_C"libopencv_cudafeatures2d.so",DEST_LIB64_PATH"libopencv_cudafeatures2d.so",ERR_UPDATE_LIB_CU_A_F},
        {UPDATE_PATH_C"libTwirlingCapture.so",DEST_LIB64_PATH"libTwirlingCapture.so",ERR_UPDATE_LIB_TW_CAPTURE},
        {UPDATE_PATH_C"libublox.so",DEST_LIB64_PATH"libublox.so",ERR_UPDATE_LIB_ULBOX},
        {UPDATE_PATH_C"libx264.so",DEST_LIB64_PATH"libx264.so",ERR_UPDATE_LIB_X264},
        {UPDATE_PATH_C"libtiff.so",DEST_LIB64_PATH"libtiff.so",ERR_UPDATE_LIB_TIFF},

        {UPDATE_PATH_C"libleveldb.so",DEST_LIB64_PATH"libleveldb.so",ERR_UPDATE_LIB_LEVELDB},
        {UPDATE_PATH_C"libstagefright_omx.so",DEST_LIB32_PATH"libstagefright_omx.so",ERR_UPDATE_LIB_STAGEFRIGHT},
                //bin
        {UPDATE_PATH_C"init.appe.sh",DEST_BIN_PATH"init.appe.sh",ERR_UPDATE_APPE},
        {UPDATE_PATH_C"msgclient",DEST_BIN_PATH"msgclient",ERR_UPDATE_MSGCLIENT},
        {UPDATE_PATH_C"rtmpd",DEST_BIN_PATH"rtmpd",ERR_UPDATE_RTMPD},
//        {UPDATE_PATH_C"init.mcfg.sh",DEST_BIN_PATH"init.mcfg.sh",ERR_UPDATE_MCFG},
        {UPDATE_PATH_C"gyro_calibration",DEST_BIN_PATH"gyro_calibration",ERR_UPDATE_GYRO_UPDATE},
        {UPDATE_PATH_C"module_tool",DEST_BIN_PATH"module_tool",ERR_UPDATE_MODULE_TOOL},
        {UPDATE_PATH_C"test_gpio",DEST_BIN_PATH"test_gpio", ERR_UPDATE_TEST_GPIO},
        {UPDATE_PATH_C"0.wav","/sdcard/noise_sample/0.wav",ERR_UPDATE_NOISE1},
        {UPDATE_PATH_C"1.wav","/sdcard/noise_sample/1.wav",ERR_UPDATE_NOISE2},
        {UPDATE_PATH_C"fanless_0.wav","/sdcard/noise_sample/fanless_0.wav",ERR_UPDATE_FANLESS_NOISE1},
        {UPDATE_PATH_C"fanless_1.wav","/sdcard/noise_sample/fanless_1.wav",ERR_UPDATE_FANLESS_NOISE2},
        //etc
        {UPDATE_PATH_C"crtmpserver.crt","/etc/crtmpserver.crt",ERR_UPDATE_RTMP_CRT},
        {UPDATE_PATH_C"crtmpserver.key","/etc/crtmpserver.key",ERR_UPDATE_RTMP_KEY},
        {UPDATE_PATH_C"cam_config.xml","/sdcard/etc/cam_config.xml",ERR_UPDATE_CAMCONFIG},
        {UPDATE_PATH_C"crtmpserver.lua","/etc/crtmpserver.lua",ERR_UPDATE_RTMP_LUA},
};

static const UPDATE_FILES mUpdatePaths[] =
{
        //must keep python at first
        {UPDATE_PATH_H"python", "/system/",ERR_UPDATE_PYTHON},
        {UPDATE_PATH_P"wav", "/data/",ERR_UPDATE_WAV},
};

static const UPDATE_FILES mUpdate_644[] =
{
        {UPDATE_PATH_P"build.prop", "/system/build.prop",ERR_UPDATE_PYTHON},
        {UPDATE_PATH_P"services.jar", "/system/framework/services.jar",ERR_UPDATE_SERVICE_JAR},
        {UPDATE_PATH_P"MediaProvider.apk", "/system/priv-app/MediaProvider/MediaProvider.apk",ERR_UPDATE_MEDIA_P_APK},
        {UPDATE_PATH_P"tegra21x_xusb_firmware", "/system/etc/firmware/tegra21x_xusb_firmware",ERR_UPDATE_XUSB},
};

//static int update_type = 0;
static UPDATE_HEADER gstHeader;

static int chmod_wifi_misc()
{
    int ret = chmod_path_777("/data/misc/wifi/");
    Log.d(TAG,"chmod misc ret %d",ret);
    return ret;
}

static int update_all644()
{
    int ret = 0;

    char buf[512];
    int iErr = 0;
    int max = 3;
    unsigned int iIndex;

    for(iIndex = 0; iIndex < sizeof(mUpdate_644)/sizeof(mUpdate_644[0]);iIndex++)
    {
        const char *src = mUpdate_644[iIndex].src;
        const char *dest = mUpdate_644[iIndex].dest;

        Log.d(TAG,"update_all644");
        if(!check_path_r(src))
        {
            Log.e(TAG,"update_all644 no read access file %s\n",src);
            continue;
        }
        else
        {
            snprintf(buf,sizeof(buf),"chmod 644 %s",src);
            if(exec_sh(buf) != 0)
            {
                Log.e(TAG,"chmod item 644 %s\n",src);
                ret = -1;
                goto EXIT;
            }
        }

        snprintf(buf,sizeof(buf),"cp -pR %s %s",src,dest);

        for (iErr = 0; iErr < max; iErr++)
        {
            if(exec_sh(buf) == 0)
            {
                snprintf(buf,sizeof(buf),"chmod 644 %s",dest);
                if(exec_sh(buf) != 0)
                {
                    Log.e(TAG,"chmod item 644 %s\n",dest);
                    ret = -1;
                    goto EXIT;
                }
                break;
            }
        }
    }
EXIT:
    return ret;
}

int finish_update()
{
    int ret = -1;
    char buf[1024];

    const char *rm_files[ ] =
    {
            UPDATE_APP_FOLD,
            UPDATE_APP_FULL_ZIP,
            UPDATE_PATH,
            UPDATE_APP_BIN_FULL_NAME,
            UPDATE_APP_CONTENT_NAME_FULL_ZIP,
    };

    for(u32 i = 0; i < sizeof(rm_files)/sizeof(rm_files[0]); i++)
    {
        ret= rm_file(rm_files[i]);
        if(ret != 0)
        {
            Log.e(TAG,"%s fail",buf);
        }
    }
    sync();
    msg_util::sleep_ms(100);
    return ret;
}

int finish_update_suc()
{
    int ret = -1;
    Log.d(TAG,"move bc");
    ret = move_bin(UPDATE_BIN_FULL_NAME,UPDATE_BIN_FULL_NAME_BC);
    if(ret != 0)
    {
        Log.d(TAG,"backup bin fail ret %d",ret);
        disp_update_error(ERR_UPDATE_BACKUP);
    }
    else
    {
        disp_update_icon(ICON_UPDATE_SUC128_64);
    }
    finish_update();
    disp_start_reboot();
    return ret;
}

static int cp_recover_backup()
{
    int ret = -1;
    if(check_path_exist(UPDATE_BIN_FULL_NAME_BC))
    {
        // use mv ,for if still update fail, not more backup use
        ret = move_bin(UPDATE_BIN_FULL_NAME_BC,UPDATE_BIN_FULL_NAME);
        if(ret != 0)
        {
            Log.d(TAG,"backup bin fail ret %d",ret);
            disp_update_error(ERR_CP_RECOVER);
        }
        else
        {
            //rm version to confirm backup has been
            rm_file(VER_FULL_PATH);
        }
    }
    else
    {
        disp_update_error(ERR_FOUND_BACKUP);
    }

    return ret;
}

int finish_update_fail()
{
    int ret = -1;
    //update backup
    finish_update();

    cp_recover_backup();

//    ret = rm_file(UPDATE_BIN_FULL_NAME);
    disp_start_reboot();

    return ret;
}

static void disp_bat_low()
{
    msg_util::sleep_ms(1000);
    disp_update_err_str("battery low");

    finish_update();
    rm_file(UPDATE_BIN_FULL_NAME);
    disp_start_reboot();
}

static u8 get_cid()
{
    return DEF_CID;
}

static u8 get_mid()
{
    return DEF_MID;
}

static bool check_header_match(UPDATE_HEADER *pstTmp)
{
    bool bRet = false;
    if (pstTmp->cid == get_cid())
    {
        if(pstTmp->mid == get_mid())
        {
            bRet = true;
        }
        else
        {
            Log.e(TAG,"header mismatch mid(%d %d)",
                    pstTmp->mid, get_mid());
            disp_update_error(ERR_APP_HEADER_MID_MISMATCH);
        }
    }
    else
    {
        Log.e(TAG,"header mismatch cid (%d %d) mid(%d %d)",
                pstTmp->cid, get_cid(), pstTmp->mid, get_mid());
        disp_update_error(ERR_APP_HEADER_CID_MISMATCH);
    }
    return bRet;
}

static bool get_pro_update_zip_suc()
{
    bool bRet = false;

    FILE *fp_bin = fopen(UPDATE_BIN_FULL_NAME,"rb");
    if(fp_bin)
    {
        u8 buf[1024 * 1024];
        u32 read_len;
        u32 update_app_len;
        u32 header_len;
        u32 content_len;
        u32 content_offset = strlen(FP_KEY) + VERSION_LEN ;

        fseek(fp_bin,content_offset,SEEK_SET);
        memset(buf,0,sizeof(buf));

        read_len = fread(buf, 1, UPDATE_APP_CONTENT_LEN,fp_bin);
        if (read_len != UPDATE_APP_CONTENT_LEN)
        {
            disp_update_error(ERR_APP_READ_APP_CONTENT);
            Log.e(TAG,"pro_update read update_app content len mismatch(%d %d)",
                    read_len,UPDATE_APP_CONTENT_LEN);
            goto EXIT;
        }
        content_offset += read_len;

        update_app_len = bytes_to_int(buf);
//        Log.d(TAG,"update_app_len is %d",update_app_len);
        content_offset += update_app_len;

        fseek(fp_bin,content_offset,SEEK_SET);

        read_len = fread(buf, 1, HEADER_CONENT_LEN, fp_bin);
        if (read_len != HEADER_CONENT_LEN)
        {
            disp_update_error(ERR_APP_READ_HEADER_LEN);
            Log.e(TAG,"header len mismatch(%d %d)",
                    read_len,HEADER_CONENT_LEN);
            goto EXIT;
        }
        dump_bytes(buf, read_len, "read header len");
        header_len = bytes_to_int(buf);

        if(header_len != sizeof(UPDATE_HEADER))
        {
            disp_update_error(ERR_APP_HEADER_LEN_MISMATCH1);
            Log.e(TAG,"header content len mismatch1(%u %zd)",
                    read_len,sizeof(UPDATE_HEADER));
            goto EXIT;
        }

        memset(buf, 0, sizeof(buf));
        read_len = fread(buf, 1, header_len, fp_bin);
//        printf("read_len %u header len %u sizeof(UPDATE_HEADER) %lu",
//            read_len,header_len, sizeof(UPDATE_HEADER));

        if (read_len != header_len)
        {
            disp_update_error(ERR_APP_HEADER_LEN_MISMATCH2);
            Log.e(TAG,"header content len mismatch2(%d %d)", read_len,header_len);
            goto EXIT;
        }

        dump_bytes(buf, header_len, "read header content");
        memcpy(&gstHeader, buf, header_len);
        if (!check_header_match(&gstHeader))
        {
            goto EXIT;
        }
        content_len = bytes_to_int(gstHeader.len);

        if (gen_file(UPDATE_APP_CONTENT_NAME_FULL_ZIP, content_len,fp_bin))
        {
//            Log.d(TAG,"start tar zip");
            if(tar_zip(UPDATE_APP_CONTENT_NAME_FULL_ZIP) == 0)
            {
                bRet = true;
            }
            else
            {
                disp_update_error(ERR_APP_TAR_ZIP);
            }
        }
        else
        {
            Log.e(TAG,"open zip %s fail",
                  UPDATE_APP_CONTENT_NAME_FULL_ZIP);
            disp_update_error(ERR_APP_GEN_ZIP);
        }
    }
    else
    {
        Log.e(TAG,"update_app open %s fail",
                UPDATE_BIN_FULL_NAME);
        disp_update_error(ERR_APP_OPEN_BIN);
    }
EXIT:
    if(fp_bin)
    {
        fclose(fp_bin);
    }
    return bRet;
}

static bool check_require_exist()
{
    bool bRet = true;

    for (u32 i = 0; i < sizeof(mUpdateRequires) / sizeof(mUpdateRequires[0]); i++)
    {
        if (!check_path_exist(mUpdateRequires[i].src))
        {
            Log.e(TAG,"update require ver %s not exists",
                    mUpdateRequires[i].dest);
            disp_update_error(mUpdateRequires[i].error_enum);
            bRet = false;
            break;
        }
    }

//    if(bRet)
//    {
//        if(!check_path_exist(UPDATE_A12_FULL_PATH))
//        {
//            disp_update_error(ERR_UPDATE_A);
//            Log.e(TAG,"update require %s not exists",
//                    UPDATE_A12_FULL_PATH);
//        }
//    }
    return bRet;
}

static int check_update_12_res()
{
    int ret = -1;
    char buf[256];
    FILE *fp = fopen(UPDATE_A12_RES_FILE,"r");
    if(fp)
    {
        u32 read_len = fread(buf, 1,sizeof(buf),fp);
        if(read_len > 0)
        {
            char *str = strstr(buf,UPDATE_A12_RES_KEY);
            if(str)
            {
                str = str + strlen(UPDATE_A12_RES_KEY);
                ret = atoi(str);

                if(ret != 0 && ret != 1)
                {
                    Log.d(TAG,"update a12 err %d %s",ret,str);
                    char err_a12[32];
//                  snprintf(err_a12,sizeof(err_a12),"a_error:%d",ret);
                    snprintf(err_a12,sizeof(err_a12),"%s","ae");
                    disp_update_err_str(err_a12);
                    str = strstr(buf,UPDATE_A12_RES_DES);
                    if(str)
                    {
                        Log.d(TAG,"update a12 err des %s",str);
                    }
                }
                else
                {
                    //make it correct
                    ret = 0;
                }
            }
        }
        else
        {
            disp_update_error(ERR_READ_A12_RES);
        }
        fclose(fp);
        rm_file(UPDATE_A12_RES_FILE);
    }
    else
    {
        disp_update_error(ERR_OPEN_A12_RES);
    }

    return ret;
}

static bool update_a12()
{
    bool ret = false;

    // a12 included
    if(check_path_exist(UPDATE_A12_FULL_PATH) || check_path_exist(UPDATE_A12_FULL_PATH_NEW))
    {
        if(check_path_exist(UPDATE_A12_VERSION_PATH))
        {
            char cmd[1024];
            const UPDATE_FILES mA12Requires[] =
            {
                    // keep ws_src at index0 for updating path
                    {UPDATE_PATH_C"module_upgrade",DEST_BIN_PATH"module_upgrade",ERR_UPDATE_UPGRADE_MODULE},
                    {UPDATE_A12_VERSION_PATH,"/data/etc/a12_version",ERR_UPDATE_A12_VER},
            };
            if (update_item(mA12Requires[0].src, mA12Requires[0].dest) != 0)
            {
                Log.e(TAG,"update %s Err",
                        mA12Requires[0].src);
                disp_update_error(mA12Requires[0].error_enum);
                goto EXIT;
            }
            //confirm module_upgrade cp suc
            sync();
            msg_util::sleep_ms(200);
            snprintf(cmd,sizeof(cmd),"module_upgrade %s",UPDATE_PATH_A);
            if(exec_sh(cmd) != 0)
            {
                Log.e(TAG,"update_a12 cmd %s error",cmd);
            }
            if(check_update_12_res() == 0)
            {
                for(u32 i = 1; i < sizeof(mA12Requires) / sizeof(mA12Requires[0]); i++)
                {
                    if (update_item(mA12Requires[i].src, mA12Requires[i].dest) != 0)
                    {
                        Log.e(TAG,"update %s Err",
                                mA12Requires[i].src);
                        disp_update_error(mA12Requires[i].error_enum);
                        goto EXIT;
                    }
                }
                ret = true;
            }
        }
        else
        {
            Log.e(TAG,"include a12 but no  %s ",
                    UPDATE_A12_VERSION_PATH);
            disp_update_error(ERR_GET_A12_VER);
        }
    }
    else
    {
        Log.d(TAG,"no a12 ");
        ret = true;
    }
EXIT:
    return ret;
}

static void move_su()
{
    const char *src = "/system/xbin/su";
    const char *dest = "/system/bin/pro_u";
    if(check_path_exist(src))
    {
        Log.d(TAG," mv su");
        move_bin(src,dest);
    }
}

#define DEST_VOLD_NEW "/system/bin/vold_new"
#define DEST_VOLD_MKEFS_NEW "/system/bin/mke2fs_new"
#define DEST_VOLD_DNSMASQ_NEW "/system/bin/dnsmasq_new"

static const UPDATE_FILES_SPEC mUpdateSpec[] =
{
        {UPDATE_PATH_P"vold", DEST_VOLD_NEW, DEST_BIN_PATH"vold", ERR_MV_VOLD_TMP,ERR_MV_VOLD,ERR_CHMOD_VOLD},
        {UPDATE_PATH_P"mke2fs", DEST_VOLD_MKEFS_NEW,DEST_BIN_PATH"mke2fs",ERR_MV_MKEFS_TMP,ERR_MV_MKEFS,ERR_CHMOD_MKEFS},
        {UPDATE_PATH_P"dnsmasq", DEST_VOLD_DNSMASQ_NEW,DEST_BIN_PATH"dnsmasq",ERR_MV_DNSMASQ_TMP,ERR_MV_DNSMASQ,ERR_CHMOD_DNSMAQ},
};

static int update_specail_bin()
{
    Log.i(TAG,"update_specail_bin");
    for (u32 i = 0; i < sizeof(mUpdateSpec) / sizeof(mUpdateSpec[i]); i++)
    {
        char buf[128];
        if(move_bin(mUpdateSpec[i].src,mUpdateSpec[i].tmp) != 0)
        {
            disp_update_error(mUpdateSpec[i].error_tmp);
            goto ERROR;
        }

        if(move_bin(mUpdateSpec[i].tmp,mUpdateSpec[i].dest) != 0)
        {
            disp_update_error(mUpdateSpec[i].error_enum);
            goto ERROR;
        }

        snprintf(buf,sizeof(buf),"chmod +x %s",mUpdateSpec[i].dest);

        if(exec_sh(buf) != 0)
        {
            disp_update_error(mUpdateSpec[i].error_chmod);
            goto ERROR;
        }
    }
    return 0;

ERROR:
    return -1;
}

static int start_update_app()
{
    int iRet = -1;

    init_oled_module();
    disp_update_icon(ICON_UPGRADE_SCHEDULE00128_64);
    if(is_bat_enough())
    {
        if (get_pro_update_zip_suc())
        {
            disp_update_icon(ICON_UPGRADE_SCHEDULE01128_64);
            if (!check_require_exist())
            {
                goto EXIT;
            }
            disp_update_icon(ICON_UPGRADE_SCHEDULE02128_64);
            if (!update_a12())
            {
                goto EXIT;
            }
            disp_update_icon(ICON_UPGRADE_SCHEDULE03128_64);
            //keep at beginning
            for (u32 i = 0; i < sizeof(mUpdatePaths) / sizeof(mUpdatePaths[i]); i++)
            {
                if (check_path_exist(mUpdatePaths[i].src))
                {
                    if (update_path(mUpdatePaths[i].src, mUpdatePaths[i].dest) != 0)
                    {
                        Log.e(TAG, "update path %s iErr",
                              mUpdatePaths[i].dest);
                        disp_update_error(mUpdatePaths[i].error_enum);
                        goto EXIT;
                    }
                    else
                    {
                        if (i == 0)
                        {
                            if (exec_sh("chmod a+x /system/python/usr/local/bin/*") != 0)
                            {
                                Log.e(TAG, "chmod python bin fail");
                                disp_update_error(ERR_APP_CHMOD_PYTHON);
                                goto EXIT;
                            }
                        }
                    }
                }
                else
                {
                    Log.e(TAG, "update path %s not exist",
                          mUpdatePaths[i].dest);
                    continue;
                }
            }
            disp_update_icon(ICON_UPGRADE_SCHEDULE04128_64);

            for (u32 i = 0; i < sizeof(mUpdateOthers) / sizeof(mUpdateOthers[0]); i++)
            {
                if (check_path_exist(mUpdateOthers[i].src))
                {
                    if (update_item(mUpdateOthers[i].src, mUpdateOthers[i].dest) != 0)
                    {
                        disp_update_error(mUpdateOthers[i].error_enum);
                        Log.e(TAG, "update %s iErr", mUpdateOthers[i].dest);
                        goto EXIT;
                    }
                }
                else
                {
                    Log.e(TAG, "other %s not exist ",
                          mUpdateOthers[i].dest);
                    if(mUpdateOthers[i].error_enum == ERR_UPDATE_B_V)
                    {
                        Log.d(TAG,"rm org %s",mUpdateOthers[i].dest);
                        rm_file(mUpdateOthers[i].dest);
                    }
                    continue;
                }
            }
            if(update_all644() != 0)
            {
                goto EXIT;
            }

            if(update_specail_bin() != 0)
            {
                goto EXIT;
            }

            disp_update_icon(ICON_UPGRADE_SCHEDULE05128_64);

            for (u32 i = 0; i < sizeof(mUpdateRequires) / sizeof(mUpdateRequires[0]); i++)
            {
                if (i == 0)
                {
                    if (update_path(mUpdateRequires[i].src, mUpdateRequires[i].dest) != 0)
                    {
                        Log.e(TAG, "update %s Err",
                              mUpdateRequires[i].dest);
                        disp_update_error(mUpdateRequires[i].error_enum);
                        goto EXIT;
                    }
                }
                else
                {
                    if (update_item(mUpdateRequires[i].src, mUpdateRequires[i].dest) != 0)
                    {
                        Log.e(TAG, "update ver %s Err",
                              mUpdateRequires[i].dest);
                        disp_update_error(mUpdateRequires[i].error_enum);
                        goto EXIT;
                    }
                }
            }
            iRet = 0;
        }
    }
    else
    {
        Log.e(TAG,"bat less e");
        disp_bat_low();
        iRet = 0;
        goto BATTERY_LESS;
    }
EXIT:
    Log.d(TAG,"start_update_app iRet %d",iRet);
    if(iRet == 0)
    {
        finish_update_suc();
    }
    else
    {
        finish_update_fail();
    }
    move_su();
BATTERY_LESS:
    return iRet;
}

int main(int argc, char **argv)
{
    int iRet = -1;

    arlog_configure(true,true,log_name,false);

    registerSig(default_signal_handler);
    signal(SIGPIPE, pipe_signal_handler);

    create_dir("/data/etc");
    create_dir("/sdcard/noise_sample");

    iRet = start_update_app();
    chmod_wifi_misc();
//    update_test_itself();
    arlog_close();
    return iRet;
}