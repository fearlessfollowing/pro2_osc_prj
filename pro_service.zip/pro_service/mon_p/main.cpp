//
// Created by vans on 17-3-24.
//
#include "../include_common.h"
#include "../sp.h"
#include "../sig_util.h"
#include "../stlog/stlog.h"
#include "../arlog.h"

static const char *log_name = "/data/m_log";
static const char *mon_name = "/system/bin/mongoose";
//static const char *kill_pro = "pkill pro_service";
#define TAG "mon_p"
int main(int argc, char **argv)
{
    int ret;
    int cnt = 0;

    registerSig(default_signal_handler);
    signal(SIGPIPE, pipe_signal_handler);

    // confirm pro_service not running
    exec_sh("pkill mongoose");
    //confirm pro_service killed
    msg_util::sleep_ms(10);
    arlog_configure(true,true,log_name,false);
    Log.d(TAG,"mon_p start");

    while(1)
    {
        ret = exec_sh(mon_name);
        msg_util::sleep_ms(50);
        Log.d(TAG,"(%d %d)",++cnt,ret);
    }

    arlog_close();
    return ret;
}