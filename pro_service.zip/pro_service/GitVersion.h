#ifndef _GIT_VERSION_H_IN
#define _GIT_VERSION_H_IN

#define GIT_SHA1 "git: ""GITDIR-NOTFOUND"" build: ""2018-04-03T03:36:29"
#endif
