//
// Created by vans on 16-12-6.
//

#ifndef PROJECT_INCLUDE_COMMON_H
#define PROJECT_INCLUDE_COMMON_H
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/statfs.h>
#include <sys/stat.h>
#include "ins_types.h"
#include "msg_util.h"
#include "util.h"
#ifdef __ANDROID__
#include "stlog/stlog.h"
#endif
#include "check.h"
#endif //PROJECT_INCLUDE_COMMON_H
