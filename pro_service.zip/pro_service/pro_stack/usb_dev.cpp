//
// Created by vans on 30/8/17.
//

#include "usb_dev.h"

usb_dev::usb_dev(u32 pid, u32 vid):pid_(pid),vid_(vid)
{

}

usb_dev::~usb_dev()
{

}

void usb_dev::init()
{

}

void usb_dev::deinit()
{

}