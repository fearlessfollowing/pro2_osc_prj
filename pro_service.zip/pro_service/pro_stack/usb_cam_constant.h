//
// Created by vans on 30/8/17.
//

#ifndef PROJECT_USB_CAM_CONSTANT_H
#define PROJECT_USB_CAM_CONSTANT_H
const int usb_cam_num = 6;
const int hub_gpio[] = {0,3};
#endif //PROJECT_USB_CAM_CONSTANT_H
