//
// Created by vans on 30/8/17.
//

#include "pub_api.h"


void pub_api::init()
{

}

void pub_api::deinit()
{

}