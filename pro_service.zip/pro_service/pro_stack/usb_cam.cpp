//
// Created by vans on 30/8/17.
//

#include "usb_cam.h"

usb_cam::usb_cam(u32 iIndex):i_cam_index_(iIndex)
{

}

usb_cam::~usb_cam()
{

}

void usb_cam::init()
{

}

void usb_cam::deinit()
{

}