//
// Created by vans on 17-3-24.
//
//#include "../include_common.h"
//#include "../sp.h"
//#include "../sig_util.h"
//#include "../ins_gpio.h"
//#include <sys/poll.h>
//#include <sys/epoll.h>

#include "video.pb.h"
#include <stdio.h>
int main(int argc, char **argv)
{
    int ret = -1;

//    printf("you choose %d rpm\n",astRPM[rpm_select].rmp);
//    registerSig(default_signal_handler);
//    signal(SIGPIPE, pipe_signal_handler);
    printf("3start test　GOOGLE_PROTOBUF_VERSION　%d\n",GOOGLE_PROTOBUF_VERSION);
#if 1
    insta360::messages::Video vidMsg;
    vidMsg.set_uri("000000000");
    vidMsg.set_file_size(0);
    vidMsg.set_total_time(0);

    // 序列化消息
    char buff[128] = {0};
    vidMsg.SerializeToArray(buff, sizeof(buff));

    for(uint32_t i  = 0; i < sizeof(buff);i++)
    {
        printf("0x%02x ",buff[i]);
        if( (i+1)%10 == 0)
        {
            printf("\n");
        }
    }

    //解析消息
    insta360::messages::Video msgread;
    msgread.ParseFromArray(buff, 11);

    printf("uri %s size %lu time %d buff len %lu\n",
           msgread.uri().c_str(),
           msgread.file_size(),
           msgread.total_time(),
            strlen(buff));
#endif
    return ret;
}