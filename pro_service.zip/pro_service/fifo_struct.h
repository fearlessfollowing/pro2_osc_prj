//
// Created by vans on 16-12-8.
//

#ifndef PROJECT_FIFO_STRUCT_H
#define PROJECT_FIFO_STRUCT_H
struct net_dev_info
{
    // dev link state
    int dev_type;
    int net_link;
    unsigned int dev_addr;
};

#endif //PROJECT_FIFO_STRUCT_H
