from . import _const


_const.PIC_FORMAT = '_pictureFormat'
_const.REC_FORMAT = '_recordFormat'
_const.PREVIEW_FORMAT = 'previewFormat'
_const.LIVE_FORMAT = '_liveFormat'
_const.VR_MODE = '_vrMode'

