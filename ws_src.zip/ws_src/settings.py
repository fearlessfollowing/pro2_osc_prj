DEBUG = True  #指定开启debug模式
PORT = 20000  #指定监听端口