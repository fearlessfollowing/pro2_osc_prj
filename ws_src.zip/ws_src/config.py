#Constants

import platform
import os
#from util.str_util import int_to_bytes

#standard
CMD_GET_STATUS = 'camera.get_status'
START_SESSION = 'camera.startSession'
UPDATE_SESSION = 'camera.updateSession'
CLOSE_SESSION = 'camera.closeSession'
PROCESS_PICTURE = 'camera.processPicture'
TAKE_PICTURE = 'camera.takePicture'
START_CAPTURE = 'camera.startCapture'
STOP_CAPTURE = 'camera.stopCapture'
GET_LIVE_PREVIEW = 'camera.getLivePreview'
LIST_IMAGES = 'camera.listImages'
LIST_FILES = 'camera.listFiles'
DELETE = 'camera.delete'
GET_IMAGE = 'camera.getImage'
GET_META_DATA = 'camera.getMetaData'
OSC_SET_OPTIONS = 'camera.setOptions'
OSC_GET_OPTIONS = 'camera.getOptions'
SET_OPTIONS = 'camera._setOptions'
GET_OPTIONS = 'camera._getOptions'
OSC_CAM_RESET = 'camera.reset'
CAMERA_RESET = 'camera._reset'

_TAKE_PICTURE = 'camera._takePicture'
#vendor define
_START_RECORD = 'camera._startRecording'
_STOP_RECORD = 'camera._stopRecording'
# _START_COMPOSE = 'camera._startCompose'
# _STOP_COMPOSE = 'camera._stopCompose'`    `1
_START_LIVE = 'camera._startLive'
_STOP_LIVE = 'camera._stopLive'
_START_CONTINUOUS_SHOT = 'camera._startContinusShoot'
_STOP_CONTINUOUS_SHOT = 'camera._stopContinusShoot'

_START_PREVIEW = 'camera._startPreview'
_STOP_PREVIEW = 'camera._stopPreview'

# _START_COMPOSE_VIDEO = 'camera._startComposeVideo'
# _STOP_COMPOSE_VIDEO = 'camera._stopComposeVideo'
# _START_COMPOSE_PIC = 'camera._ComposePicture'

_START_STICH_VIDEO = 'camera._startStichVideoFile'
_STOP_STICH_VIDEO = 'camera._stopStichVideoFile'
_START_STICH_PIC = 'camera._stichPictureFile'

#{"name": "camera._update_gamma_curve", "parameters":{"path":"/sdcard/gamma_curve.bin"}}
_UPDATE_GAMMA_CURVE = 'camera._update_gamma_curve'

_SET_NTSC_PAL = 'camera._setNtscPal'
_GET_NTSC_PAL = 'camera._getNtscPal'

_VERSION = 'camera._version'

# _TEST_RW_SPEED = 'camera._testRWSpeed'
_GET_MEDIA = '_getMedia'

_UPLOAD_FILE = '_uploadFile'
_DOWNLOAD_FILE = '_downloadFile'

_CONNECT = 'camera._connect'
_DISCONNECT = 'camera._disconnect'
_SETOFFSET = 'camera._setOffset'
_GETOFFSET = "camera._getOffset"
_SET_IMAGE_PARAM = 'camera._setImageParam'
_GET_IMAGE_PARAM = 'camera._getImageParam'
_SET_WIFI_CONFIG = 'camera._setWifiConfig'
# _SET_HDMI_ON = 'camera._hdmiOn'
# _SET_HDMI_OFF = 'camera._hdmiOff'

_STATE_NOTIFY = 'camera._stateIndication'
_RECORD_FINISH = 'camera._record_finish_'
_PIC_NOTIFY = 'camera._pic_finish_'
_RESET_NOTIFY = 'camera._resetIndication'
_LIVE_FINISH = 'camera._live_finish_'
_LIVE_REC_FINISH = 'camera._live_rec_finish_'
_QR_NOTIFY = 'camera._qr_scan_finish_'
_CALIBRATION_NOTIFY = 'camera._calibration_finish_'
_PREVIEW_FINISH = 'camera._preview_finish_'
#send live fps
_LIVE_STATUS = 'camera._live_stats_'
#update live net state
_NET_LINK_STATUS = 'camera._net_link_state_'
_GYRO_CALIBRATION = 'camera._gyro_calibration_finish_'
_SPEED_TEST_NOTIFY = 'camera._storage_speed_test_finish_'
_STOP_REC_FINISH = 'camera._stop_record_finish_'
_STOP_LIVE_FINISH = 'camera._stop_live_finish_'
_PIC_ORG_FINISH = 'camera._pic_origin_finish_'
_TIMELAPSE_PIC_FINISH = 'camera._timelapse_pic_take_'

_SET_STORAGE_PATH = 'camera._changeStoragePath'
_GET_STORAGE_PATH= 'camera._getStoragePath'
_QUERY_STATE = 'camera._queryState'
_CALIBRATION = 'camera._calibration'
_GET_RESULTS = 'camera._getResult'

_BLC_FINISH = 'camera._calibrationBlcResult_'
_CAL_ORG_FINISH = 'camera._calibration_origin_finish_'

_NOISE_FINISH ='camera._capture_audio_finish_'

_GPS_NOTIFY = 'camera._gps_state_'
_SND_NOTIFY = 'camera._snd_state_'

_STITCH_NOTIFY = 'stitcher.task_stats_'

_START_QR = 'camera._startQRCodeScan'
_STOP_QR = 'camera._stopQRCodeScan'


_SET_CUSTOM='camera._setCustom'
_GET_CUSTOM='camera._getCustom'

_SET_SYS_SETTING='camera._setSysSetting'

_GET_SYS_SETTING='camera._getSysSetting'

_SET_SN='camera._setSN'
_GET_SN='camera._getSN'

_LOW_BAT_PROTECT='camera._lowBatAct'
_POWER_OFF='camera._powerOff'
_SPEED_TEST='camera._storageSpeedTest'
_START_GYRO='camera._gyroCalibration'

_START_SHELL='camera._startShell'

_START_SINGLE_PIC = 'camera._singlenTakePicture'
_START_SINGLE_PREVIEW = 'camera._startSinglenPreview'

_START_NOISE = 'camera._startCaptureAudio'
_STOP_NOISE = 'camera._stopCaptureAudio'
_SYS_TIME_CHANGE = 'camera._systemTimeChange'

_CALIBTRATE_BLC = 'camera._calibrationBlc'

#stich

_STITCH_CONNECT = 'camera._stitchConnect'
_STITCH_DISCONNECT = 'camera._stitchDisConnect'

_STITCH_START = 'stitcher.start_stitching_box'
_STITCH_STOP = 'stitcher.stop_stitching_box'

# 老化测试结果
_AGEINT_RESULT = 'camera._record_finish_'




#path
PATH_STATE = '/osc/state'
PATH_CHECK_UPDATE = '/osc/checkForUpdates'
PATH_CMD_EXECUTE = '/osc/commands/execute'
PATH_CMD_STATUS = '/osc/commands/status'
PATH_INFO = '/osc/info'

PATH_CMD_STITCH = '/osc/commands/stitch'
# PATH_PIC_NAME = '/osc/pic/<media_name>'

"""camera_state"""
STATE_IDLE = 0x00
STATE_RECORD = 0x01
STATE_TAKE_CAPTURE_IN_PROCESS = 0x02
STATE_COMPOSE_IN_PROCESS = 0x04
STATE_PREVIEW = 0x08
STATE_LIVE = 0x10
STATE_PIC_STITCHING = 0x20
#STATE_HDMI = 0x20
# CONTINUOUS_SHOT = 0x20
STATE_CALIBRATING = 0x1000
STATE_START_PREVIEWING = 0x2000
STATE_STOP_PREVIEWING = 0x4000
STATE_START_QR = 0x8000
# STATE_STOP_QR = 0x10000
STATE_STOP_QRING = 0x20000
STATE_LIVE_CONNECTING = 0x80000
STATE_LOW_BAT = 0x100000
STATE_POWER_OFF = 0x200000
STATE_SPEED_TEST = 0x400000
STATE_START_GYRO = 0x800000
STATE_NOISE_SAMPLE = 0x1000000
STATE_EXCEPTION = 0x8000000

STATE_BLC_CALIBRATE = 0x10000000
#used to force syncing
STATE_TEST = 0x8000001

#json param
MIME = 'mime'
WIDTH = 'width'
HEIGHT = 'height'
MODE = 'mode'
PREFIX = 'prefix'
NUM = 'num'
_NAME = 'name'
_STATE = 'state'
PARAM = 'parameters'

ORG = 'origin'
STICH = 'stiching'
AUD = 'audio'
LIVE_AUTO_CONNECT='autoConnect'

FILE_TYPE = 'fileType'
SAVE_ORG = 'saveOrigin'
FRAME_RATE = 'framerate'
#BIT_RATE = 'bitrate'

#audio
SAMPLE_FMT = 'sampleFormat'
CHANNEL_LAYOUT = 'channelLayout'
#CAMERA_INDEX = 'camera_index'
BIT_RATE ='bitrate'
SAMPLE_RATE ='samplerate'

HDR = 'hdr'
PICTURE_COUNT= 'pictureCount'
PICTURE_INTER = 'pictureInter'

DURATION = 'duration'

OS_READ_LEN = 1024

HEADER_LEN = 8
# CONTENT_LEN = 4
CONTENT_LEN_OFF = HEADER_LEN - 4
# HEADER_BYTES = int_to_bytes(HEADER_LEN)

#http method
HTTP_MOTHOD =['GET', 'POST']

if platform.machine() == 'x86_64':
    BASE_PATH = os.environ.get('HOME') + '/'
    INS_FIFO_TO_SERVER= BASE_PATH + 'ins_fifo_to_server'
    INS_FIFO_TO_CLIENT= BASE_PATH + 'ins_fifo_to_client'
    MONITOR_FIFO_WRITE = BASE_PATH + 'fifo_read_client'
    MONITOR_FIFO_READ = BASE_PATH + 'fifo_write_client'
    INS_ACTIVE_FROM_CAMERA = BASE_PATH + 'ins_fifo_to_client_a'
    INS_FIFO_RESET_TO = BASE_PATH + 'ins_fifo_to_server_father'
    INS_FIFO_RESET_FROM = BASE_PATH + 'ins_fifo_to_client_father'
    # ETH_DEV = 'eth0'
    BROWER_ROOT= BASE_PATH
    STORAGE_ROOT = BROWER_ROOT + 'sdcard/'
    # LOG_ROOT = STORAGE_ROOT + 'py_log/'
    LOG_FILE = STORAGE_ROOT + 'h_log'
    # DB_NAME = BROWER_ROOT + '360_pro'
    ADD_STORAGE = STORAGE_ROOT
    USER_RELOAD = False
    UPLOAD_DIR = BASE_PATH + 'upload/'
elif platform.machine() == 'aarch64':
    # FIFO文件存放的目录
    BASE_PATH = '/home/nvidia/insta360/fifo/'
    MONITOR_FIFO_WRITE = BASE_PATH + 'fifo_read_client'
    MONITOR_FIFO_READ = BASE_PATH + 'fifo_write_client'
    INS_FIFO_TO_SERVER= BASE_PATH + 'ins_fifo_to_server'
    INS_FIFO_TO_CLIENT= BASE_PATH + 'ins_fifo_to_client'

    #read callback from camera,normally recevied while camerad hungup
    INS_ACTIVE_FROM_CAMERA = BASE_PATH + 'ins_fifo_to_client_a'
    INS_FIFO_RESET_TO = BASE_PATH + 'ins_fifo_to_server_father'
    INS_FIFO_RESET_FROM = BASE_PATH + 'ins_fifo_to_client_father'

    # ETH_DEV = 'eth0'
    BROWER_ROOT = '/data/'
    STORAGE_ROOT = BROWER_ROOT
    
    # LOG_ROOT = STORAGE_ROOT + 'py_log/'
    LOG_FILE = STORAGE_ROOT + 'h_log'
    # DB_NAME = STORAGE_ROOT + '360_pro'

    ADD_STORAGE = '/sdcard/'
    USER_RELOAD = False
    UPLOAD_DIR = '/data/uploads'
    
else:
    MONITOR_FIFO_WRITE = '/data/fifo_read_client'
    MONITOR_FIFO_READ = '/data/fifo_write_client'
    INS_FIFO_TO_SERVER='/data/ins_fifo_to_server'
    INS_FIFO_TO_CLIENT='/data/ins_fifo_to_client'
    #read callback from camera,normally recevied while camerad hungup
    INS_ACTIVE_FROM_CAMERA = '/data/ins_fifo_to_client_a'
    INS_FIFO_RESET_TO = '/data/ins_fifo_to_server_father'
    INS_FIFO_RESET_FROM = '/data/ins_fifo_to_client_father'
    # ETH_DEV = 'eth0'
    BROWER_ROOT = '/data/'
    STORAGE_ROOT = BROWER_ROOT
    # LOG_ROOT = STORAGE_ROOT + 'py_log/'
    LOG_FILE = STORAGE_ROOT + 'h_log'
    # DB_NAME = STORAGE_ROOT + '360_pro'
    ADD_STORAGE = '/sdcard/'
    USER_RELOAD = False
    UPLOAD_DIR = '/data/uploads'

#error des
UNKONWNCOMMAND = {'unknownCommand':'Invalid command is issued'}
DISABLEDCOMMAND = { 'DISABLEDCOMMAND':'Command cannot be executed due to the camera status'}
MISSINGPARAMETER = { 'MISSINGPARAMETER':'Insufficient required parameters to issue the command'}
INVALIDPARAMETERNAME	= { 'INVALIDPARAMETERNAME':'Parameter name or option name is invalid'}
INVALIDPARAMETERVALUE = { 'INVALIDPARAMETERVALUE':'Parameter value when command was issued is invalid'}
TOOMANYPARAMETERS= { 'TOOMANYPARAMETERS':'Number of parameters exceeds limit'}
CORRUPTEDFILE= {'CORRUPTEDFILE':'Process request for corrupted file'}
POWEROFFSEQUENCERUNNING= { 'POWEROFFSEQUENCERUNNING':'Process request when power supply is off'}
INVALIDFILEFORMAT= { 'INVALIDFILEFORMAT':'Invalid file format specified'}
SERVICEUNAVAILABLE= { 'SERVICEUNAVAILABLE':'Processing requests cannot be received temporarily'}
#Returned in Commands/Status of camera.takePicture
CANCELEDSHOOTING= { 'CANCELEDSHOOTING':'Shooting request cancellation of the self-timer'}
UNEXPECTED= {'UNEXPECTED':'Other errors'}

#state res
DONE = 'done'
IN_PROGRESS = 'inProgress'
ERROR = 'error'
RESULTS = 'results'
FINGERPRINT = 'Fingerprint'

# #pro file path
# BASE_DIR = '/sdcard/'
# UPLOAD_DIR = BASE_DIR + 'upload/'

PIC_FORMAT = '_pictureFormat'
REC_FORMAT = '_recordFormat'
PREVIEW_FORMAT = 'previewFormat'
LIVE_FORMAT = '_liveFormat'
VR_MODE = '_vrMode'

PREVIEW_URL = '_previewUrl'
RECORD_URL = '_recordUrl'
LIVE_URL = '_liveUrl'

ORG_URL_LIST='_orgURLList'

#write fifo msg
# OLED_DISP_STR = 'oled_disp_str'
# OLED_DISP_EXT = 'oled_disp_ext'
# OLED_KEY_RES = 'oled_key_res'
OLED_DISP_TYPE = 'oled_disp_type'
OLED_DISP_TYPE_ERR = 'oled_disp_type_err'
OLED_CONIFIG_WIFI = 'oled_config_wifi'
OLED_SET_SN = 'oled_set_sn'
# OLED_POWER_OFF = 'oled_power_off'
OLED_SYNC_INIT = 'oled_sync_init'

# STR_START_REC = 1
# STR_START_REC = 1
# STR_START_REC = 1
# STR_START_REC = 1
# STR_START_REC = 1
# STR_START_REC = 1

# REC = 0
# REC_FAIL = 1
# SAVE_REC_SUC = 2
# SAVE_REC_FAIL = 3
# CAPTURE = 4
# CAPTURE_FAIL = 5
# SAVE_CAPTURE = 6
# # SAVE_CAPTURE_FAIL = 7
# START_LIVE_SUC = 8
# LIVE_FAIL = 9
# STOP_LIVE_SUC = 10
# STOP_LIVE_FAIL = 11
# # COMPOSE_PIC = 12
# # COMPOSE_PIC_FAIL = 13
# # COMPOSE_PIC_SUC = 14
# # COMPOSE_VIDEO = 15
# # COMPOSE_VIDEO_FAIL = 16
# COMPOSE = 12
# COMPOSE_OVER = 13
# COMPOSE_VIDEO_SUC = 17
#
#
# RESET = 30

# SET_OFFSET = 30
# SET_OFFSET_FAIL = 31

START_RECING = 0,
START_REC_SUC = 1
START_REC_FAIL = 2
STOP_RECING = 3,
STOP_REC_SUC= 4
STOP_REC_FAIL= 5
CAPTURE= 6
CAPTURE_SUC= 7
CAPTURE_FAIL= 8
COMPOSE_PIC = 9
COMPOSE_PIC_FAIL = 10
COMPOSE_PIC_SUC =11
COMPOSE_VIDEO = 12
COMPOSE_VIDEO_FAIL =13
COMPOSE_VIDEO_SUC = 14
STRAT_LIVING = 15
START_LIVE_SUC = 16
START_LIVE_FAIL = 17
STOP_LIVING = 18
STOP_LIVE_SUC = 19
STOP_LIVE_FAIL = 20
PIC_ORG_FINISH = 21
START_LIVE_CONNECTING = 22
START_CALIBRATIONING = 27
CALIBRATION_SUC = 28
CALIBRATION_FAIL = 29
START_PREVIEWING=30
START_PREVIEW_SUC=31
START_PREVIEW_FAIL=32
STOP_PREVIEWING = 33
STOP_PREVIEW_SUC=34
STOP_PREVIEW_FAIL=35
START_QRING = 36
START_QR_SUC = 37
START_QR_FAIL =38
STOP_QRING = 39
STOP_QR_SUC = 40
STOP_QR_FAIL = 41
QR_FINISH_CORRECT = 42
QR_FINISH_ERROR = 43
CAPTURE_ORG_SUC = 44
CALIBRATION_ORG_SUC = 45
SET_CUS_PARAM=46

QR_FINISH_UNRECOGNIZE=47

TIMELPASE_COUNT=48
START_NOISE_SUC = 49
START_NOISE_FAIL = 50
START_NOISE = 51
START_LOW_BAT_SUC = 52
START_LOW_BAT_FAIL = 53
LIVE_REC_OVER = 54

SET_SYS_SETTING=55
# NOISE_FINISH_ERR = 51
# NOISE_FINISH_SUC = 52

STITCH_PROGRESS = 56
STITCH_FINISH = 57

START_BLC = 70
STOP_BLC = 71

START_GYRO = 73
START_GYRO_SUC = 74
START_GYRO_FAIL = 75
SPEED_TEST_SUC=76
SPEED_TEST_FAIL=77
SPEED_START = 78
SYNC_REC_AND_PREVIEW= 80
SYNC_LIVE_AND_PREVIEW= 90
SYNC_LIVE_CONNECTING_AND_PREVIEW= 91

START_AGEING_FAIL = 97
START_AGEING= 98
START_FORCE_IDLE = 99
RESET_ALL = 100
WRITE_FOR_BROKEN = 101
RESET_ALL_CFG = 102

HTTP_ASYNC=True

MODE_3D = '3d_top_left'
MODE_PANO='pano'

#osc err
OSC_UNKNOWN='unknownCommand'
OSC_DISABLE='disabledCommand'
OSC_CAM_IN_EXC='cameraInExclusiveUse'
OSC_MISS_P='missingParameter'
OSC_INVALID_PN='invalidParameterName'
OSC_INVALID_PV='invalidParameterValue'

_ID_GOT='got'
#add for google osc server 170915
HTTP_ROOT='http://192.168.43.1:8000'





#support file suffix
